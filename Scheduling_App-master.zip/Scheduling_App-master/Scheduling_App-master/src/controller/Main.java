package controller;

import DAO.JDBC;
import DAO.LoginAttemptsImplementation;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;


/**
 * Main is a controller class for making a JDBC connection and loading Login.fxml screen
 *
 * @author Jacob Douma
 */
public class Main extends Application {

    /**
     * Method which loads and displays Login form
     * @param stage
     * @throws IOException
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        //stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which establishes JDBC connection, launches the program, and appends login attempts when program exited
     * @param args
     */
    public static void main(String[] args) {
        /*Login Screen
         *userName:"test"
         *Password:"test"
         */
        JDBC.makeConnection();
        launch();

        //When Window is closed, will return to main, so append login attempts and serialize deleted records here
        MenuController.serializeDeletedRecords();
        LoginAttemptsImplementation.appendLoginAttempts();
        JDBC.closeConnection();
    }
}
