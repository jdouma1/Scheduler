package controller;

import DAO.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Customers;

import java.io.*;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;


/**
 * <p>MenuController is a controller class for viewing, adding, updating and deleting appointment and customer records.</p>
 * <p>MenuController also allows for viewing Reports.</p>
 *
 * @author Jacob Douma
 */
public class MenuController implements Initializable {

    /**TableView for displaying customer records*/
    public TableView customersTable;

    /**TableColumn for displaying customerId*/
    public TableColumn customerIdColumn;

    /**TableColumn for displaying customerName*/
    public TableColumn customerNameColumn;

    /**TableColumn for displaying customerAddress*/
    public TableColumn customerAddressColumn;

    /**TableColumn for displaying customerPostalCode*/
    public TableColumn customerPostalCodeColumn;

    /**TableColumn for displaying customerPhone*/
    public TableColumn customerPhoneColumn;

    /**TableColumn for displaying customerDivisionId*/
    public TableColumn customerDivisionIdColumn;

    /**TableView for displaying appointment records*/
    public TableView appointmentsTable;

    /**TableColumn for displaying appointmentId*/
    public TableColumn appointmentIdColumn;

    /**TableColumn for displaying appointmentTitle*/
    public TableColumn appointmentTitleColumn;

    /**TableColumn for displaying appointmentDescription*/
    public TableColumn appointmentDescriptionColumn;

    /**TableColumn for displaying appointmentLocation*/
    public TableColumn appointmentLocationColumn;

    /**TableColumn for displaying appointmentContact*/
    public TableColumn appointmentContactColumn;

    /**TableColumn for displaying appointmentType*/
    public TableColumn appointmentTypeColumn;

    /**TableColumn for displaying appointmentStart*/
    public TableColumn appointmentStartDateTimeColumn;

    /**TableColumn for displaying appointmentEnd*/
    public TableColumn appointmentEndDateTimeColumn;

    /**TableColumn for displaying appointmentTitle*/
    public TableColumn appointmentCustomerIdColumn;

    /**TableColumn for displaying appointmentUserId*/
    public TableColumn appointmentUserIdColumn;

    /**RadioButton for displaying appointments by week*/
    public RadioButton weekRadioButton;

    /**RadioButton for displaying appointments by month*/
    public RadioButton monthRadioButton;

    /**Tracks firstLogin to check for upcoming appointments upon initial login*/
    private static boolean firstLogin = true;

    /**Boolean value determines alert for upcoming appointment or no appointment*/
    private boolean upcomingAppointment = false;

    /**Boolean value determines if records have been deserialized upon initial login*/
    private static boolean deserialized = false;


    /**
     * <p>Method which initializes customer and appointment tables, as well as records</p>
     * <p>Used lambda to easily iterate through appointments list and check/display upcoming appointment alert</p>
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        CustomersImplementation.initialize();
        AppointmentsImplementation.initialize();
        if (!deserialized) {
            deserializeDeletedRecords();
        }

        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        customerAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        customerPostalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        customerPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        customerDivisionIdColumn.setCellValueFactory(new PropertyValueFactory<>("divisionId"));
        customersTable.setItems(CustomersImplementation.getAllCustomers());

        appointmentIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        appointmentTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        appointmentDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        appointmentLocationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        appointmentContactColumn.setCellValueFactory(new PropertyValueFactory<>("contact"));
        appointmentTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        appointmentStartDateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("startLocal"));
        appointmentEndDateTimeColumn.setCellValueFactory(new PropertyValueFactory<>("endLocal"));
        appointmentCustomerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        appointmentUserIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        appointmentsTable.setItems(AppointmentsImplementation.getAllAppointments());

        //USED LAMBDA EXPRESSION
        //Check for appointment within 15 minutes of login
        if (firstLogin) {
            firstLogin = false;
            AppointmentsImplementation.getAllAppointments().forEach(a -> checkUpcomingAppointment(a));

            if (!upcomingAppointment) {
                noAppointmentAlert();
            }
        }

    }

    /**
     * Method which checks date and time to see if there are any upcoming appointments
     * @param a
     */
    public void checkUpcomingAppointment(Appointments a) {
        LocalDateTime ldtStart = a.getStartLocal().toLocalDateTime();
        if (LocalDateTime.now().getDayOfYear() == ldtStart.getDayOfYear()) {
            if (LocalDateTime.now().getHour() == ldtStart.getHour()) {
                if ((ldtStart.getMinute() - LocalDateTime.now().getMinute() >= 0)
                    && (ldtStart.getMinute() - LocalDateTime.now().getMinute() <= 15)) {
                    //Upcoming appointment
                    upcomingAppointment = true;
                    upcomingAppointmentAlert(a);
                }
            }
            else if (LocalDateTime.now().getHour() + 1 == ldtStart.getHour()) {
                if (LocalDateTime.now().getMinute() >= 45 && ldtStart.getMinute() == 0) {
                    //Upcoming appointment
                    upcomingAppointment = true;
                    upcomingAppointmentAlert(a);
                }
            }
        }
    }

    /**
     * Method which generates alert that there is an upcoming appointment
     * @param a
     */
    public void upcomingAppointmentAlert(Appointments a) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("APPOINTMENTS");
        alert.setHeaderText("Upcoming appointment");
        alert.setContentText("You have an appointment within 15 minutes:\n\n" +
                             "Appointment ID: " + a.getAppointmentId() +
                             "\nDate: " + a.getStartLocal().toLocalDateTime().toLocalDate() +
                             "\nTime: " + a.getStartLocal().toLocalDateTime().toLocalTime()
                             );
        alert.showAndWait();
    }

    /**
     * Method which generates alert that there are no upcoming appointments
     */
    public void noAppointmentAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("APPOINTMENTS");
        alert.setHeaderText("No upcoming appointments");
        alert.setContentText("You have no upcoming appointments within 15 minutes");

        alert.showAndWait();
    }

    /**
     * Method which adds customer through AddCustomersController.java
     * @param actionEvent
     * @throws IOException
     */
    public void onAddCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/AddCustomers.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which generates selected customer and switches to UpdateCustomersController.java to update customer
     * @param actionEvent
     * @throws IOException
     * @throws SQLException
     */
    public void onUpdateCustomer(ActionEvent actionEvent) throws IOException, SQLException {
        Customers selectedCustomer = (Customers) customersTable.getSelectionModel().getSelectedItem();

        if (selectedCustomer == null) {
            return;
        }
        UpdateCustomersController.generateCustomer(selectedCustomer);

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/UpdateCustomers.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which confirms deleting customer and displays confirmation alert
     * @param actionEvent
     */
    public void onDeleteCustomer(ActionEvent actionEvent) {
        Customers selectedCustomer = (Customers) customersTable.getSelectionModel().getSelectedItem();

        if (selectedCustomer != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("CUSTOMERS");
            alert.setHeaderText("Delete");
            alert.setContentText("Do you want to delete this customer?");

            Optional<ButtonType> buttonResult = alert.showAndWait();

            if (buttonResult.isPresent() && buttonResult.get() == ButtonType.OK) {
                Query.makeQuery("SELECT * FROM appointments");
                ResultSet result = Query.getResult();

                try {
                    while (result.next()) {
                        if (selectedCustomer.getId() == result.getInt("Customer_ID")) {
                            Appointments a = AppointmentsImplementation.getAppointment(result.getInt("Appointment_ID"));
                            AppointmentsImplementation.delete(a);
                        }
                    }
                    CustomersImplementation.delete(selectedCustomer);
                    customersTable.setItems(CustomersImplementation.getAllCustomers());
                } catch(Exception e) {

                }
            }
        }
    }

    /**
     * Method which adds appointment through AddAppointmentsController.java
     * @param actionEvent
     * @throws IOException
     */
    public void onAddAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/AddAppointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which generates selected appointment and switches to UpdateAppointmentsController.java to update appointment
     * @param actionEvent
     * @throws IOException
     */
    public void onUpdateAppointment(ActionEvent actionEvent) throws IOException {
        Appointments selectedAppointment = (Appointments) appointmentsTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment == null) {
            return;
        }
        UpdateAppointmentsController.generateAppointment(selectedAppointment);

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/UpdateAppointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which confirms deleting appointment and displays confirmation alerts
     * @param actionEvent
     */
    public void onDeleteAppointment(ActionEvent actionEvent) {
        Appointments selectedAppointment = (Appointments) appointmentsTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("APPOINTMENTS");
            alert.setHeaderText("Delete");
            alert.setContentText("Do you want to delete this appointment?");

            Optional<ButtonType> buttonResult = alert.showAndWait();

            if (buttonResult.isPresent() && buttonResult.get() == ButtonType.OK) {
                alert.setAlertType(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Canceled");
                alert.setContentText("Appointment\n\n" + "Appointment_ID: " + selectedAppointment.getAppointmentId() + "\n" +
                                     "Type: " + selectedAppointment.getType() + "\n\n" +
                                     "successfully canceled.");
                buttonResult = alert.showAndWait();

                AppointmentsImplementation.delete(selectedAppointment);
                appointmentsTable.setItems(AppointmentsImplementation.getAllAppointments());
            }
        }
    }

    /**
     * Method which generates int corresponding to day of week
     * @param d
     * @return int day value
     */
    public int getDayValue(DayOfWeek d) {
        switch(d) {
            case SUNDAY:
                return 1;
            case MONDAY:
                return 2;
            case TUESDAY:
                return 3;
            case WEDNESDAY:
                return 4;
            case THURSDAY:
                return 5;
            case FRIDAY:
                return 6;
            case SATURDAY:
                return 7;
        }
        return 0;
    }

    /**
     * Method which onSelectedWeek()
     * Determines if appointment dates are in current week of year
     * @param appointment
     * @return true if in current week, otherwise false
     */
    public boolean appointmentInCurrentWeek(Appointments appointment) {
        //Checks appointments are within 0-6 days ahead and 0-6 days behind current day
        //Checks appointments are within same work week (Sunday through Saturday)

        //Validates prior days of week as well as current
        //Appointment must be same day of week or lesser day of week
        //Day of year difference must be no less than 6 days prior and no greater than 0 (same day)
        if (getDayValue(LocalDateTime.now().getDayOfWeek()) - getDayValue(appointment.getStart().toLocalDateTime().getDayOfWeek()) >= 0
                && LocalDateTime.now().getDayOfYear() - appointment.getStart().toLocalDateTime().getDayOfYear() <= 6
                && LocalDateTime.now().getDayOfYear() - appointment.getStart().toLocalDateTime().getDayOfYear() >= 0
        ) {
            //appointmentsFilteredByWeek.add(appointment);
            return true;
        }
        //Validates days ahead in week
        //Appointment must be greater day of week
        //Day of year difference must be no less than 1 days after and no greater than 6 days after
        else if (getDayValue(appointment.getStart().toLocalDateTime().getDayOfWeek()) - getDayValue(LocalDateTime.now().getDayOfWeek()) > 0
                && appointment.getStart().toLocalDateTime().getDayOfYear() - LocalDateTime.now().getDayOfYear() <= 6
                && appointment.getStart().toLocalDateTime().getDayOfYear() - LocalDateTime.now().getDayOfYear() >= 1
        ) {
            //appointmentsFilteredByWeek.add(appointment);
            return true;
        }
        return false;
    }

    /**
     * <p>Method which displays appointments filtered by week</p>
     * <p>Uses lambda to easily stream and filter whether appointmentInCurrentWeek(), set to list, and display list</p>
     * @param actionEvent
     */
    public void onSelectedWeek(ActionEvent actionEvent) {
        //USES LAMBDA EXPRESSION
        List<Appointments> appointmentsFilteredByWeek = AppointmentsImplementation.getAllAppointments()
                .stream()
                .filter(a -> appointmentInCurrentWeek(a))
                .collect(Collectors.toList());
        appointmentsTable.setItems(FXCollections.observableArrayList(appointmentsFilteredByWeek));
    }

    /**
     * <p>Method which displays appointments filtered by month</p>
     * <p>Uses lambda to easily stream and filter whether appointment is in current month, set to list, and display list</p>
     * @param actionEvent
     */
    public void onSelectedMonth(ActionEvent actionEvent) {
        //USES LAMBDA EXPRESSION
        List<Appointments> appointmentsFilteredByMonth = AppointmentsImplementation.getAllAppointments()
                .stream()
                .filter(a -> a.getStart().toLocalDateTime().getMonth() == LocalDateTime.now().getMonth())
                .collect(Collectors.toList());
        appointmentsTable.setItems(FXCollections.observableArrayList(appointmentsFilteredByMonth));
    }

    /**
     * Method which displays all appointments
     * @param actionEvent
     */
    public void onSelectedAll(ActionEvent actionEvent) {
        appointmentsTable.setItems(AppointmentsImplementation.getAllAppointments());
    }

    /**
     * Method which serializes records to DeletedAppointmentsSerialized.txt and DeletedCustomersSerialized.txt
     */
    public static void serializeDeletedRecords() {
        ObservableList<Customers> deletedCustomers = CustomersImplementation.getAllDeletedCustomers();
        ObservableList<Appointments> deletedAppointments = AppointmentsImplementation.getAllDeletedAppointments();
        String customersFilename = "Scheduling_App-master/src/Utilities/DeletedCustomersSerialized.txt";
        String appointmentsFilename = "Scheduling_App-master/src/Utilities/DeletedAppointmentsSerialized.txt";

        try {
            //Serialize deleted customers
            FileOutputStream file = new FileOutputStream(customersFilename);
            ObjectOutputStream out = new ObjectOutputStream(file);

            if (deletedCustomers != null && !deletedCustomers.isEmpty()) {
                out.writeObject(new ArrayList<Customers>(deletedCustomers));
                System.out.println("Deleted customers have been serialized");
            }
            out.flush();
            out.close();
            file.flush();
            file.close();


            //Serialize deleted appointments
            file = new FileOutputStream(appointmentsFilename);
            out = new ObjectOutputStream(file);

            if (deletedAppointments != null && !deletedAppointments.isEmpty()) {
                out.writeObject(new ArrayList<Appointments>(deletedAppointments));
                System.out.println("Deleted appointments have been serialized");
            }
            out.flush();
            out.close();
            file.flush();
            file.close();
        }

        catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Method which deserializes deleted records from DeletedAppointmentsSerialized.txt and DeletedCustomersSerialized.txt
     */
    public void deserializeDeletedRecords() {
        ObservableList<Customers> deletedCustomers;
        ObservableList<Appointments> deletedAppointments;
        String customersFilename = "Scheduling_App-master/src/Utilities/DeletedCustomersSerialized.txt";
        String appointmentsFilename = "Scheduling_App-master/src/Utilities/DeletedAppointmentsSerialized.txt";

        try {
            deserialized = true;

            //Deserialize deleted customers
            FileInputStream file = new FileInputStream(customersFilename);
            ObjectInputStream in = new ObjectInputStream(file);

            List<Customers> customers = (List<Customers>) in.readObject();
            if (!customers.isEmpty()) {
                deletedCustomers = FXCollections.observableArrayList(customers);
                CustomersImplementation.setAllDeletedCustomers(deletedCustomers);
                System.out.println("Deleted customers have been deserialized");
                System.out.println(deletedCustomers);
            }
            in.close();
            file.close();


            //Deserialize deleted appointments
            file = new FileInputStream(appointmentsFilename);
            in = new ObjectInputStream(file);

            List<Appointments> appointments = (List<Appointments>) in.readObject();
            if (!appointments.isEmpty()) {
                deletedAppointments = FXCollections.observableArrayList(appointments);
                AppointmentsImplementation.setAllDeletedAppointments(deletedAppointments);
                System.out.println("Deleted appointments have been deserialized");
                System.out.println(deletedAppointments);
            }
            in.close();
            file.close();
        }

        catch(Exception e) {
            System.out.println(e.getMessage());
            System.out.println("EMPTY DELETED RECORDS IN CUSTOMERS AND/OR APPOINTMENTS");
        }
    }

    /**
     * Method which switches to reports screen
     * @param actionEvent
     * @throws IOException
     */
    public void onSelectedReports(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Reports.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which closes application, serializes records, appends login attempts, and closes JDBC connection
     * @param actionEvent
     */
    public void onExitMenu(ActionEvent actionEvent) {
        MenuController.serializeDeletedRecords();
        LoginAttemptsImplementation.appendLoginAttempts();
        JDBC.closeConnection();
        System.exit(0);
    }
}
