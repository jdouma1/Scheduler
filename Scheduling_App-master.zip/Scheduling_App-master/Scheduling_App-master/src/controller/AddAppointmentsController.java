package controller;

import DAO.AppointmentsImplementation;
import DAO.Query;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.*;
import java.util.ResourceBundle;


/**
 * AddCustomersController is a controller class for adding appointment records to DB
 *
 * @author Jacob Douma
 */
public class AddAppointmentsController implements Initializable {

    /**Disabled TextField for viewing appointment ID*/
    public TextField appointmentIdField;

    /**TextField for setting appointment title*/
    public TextField appointmentTitleField;

    /**TextField for setting appointment description*/
    public TextField appointmentDescriptionField;

    /**TextField for setting appointment location*/
    public TextField appointmentLocationField;

    /**TextField for setting appointment contact*/
    public ComboBox appointmentContactComboBox;

    /**TextField for setting appointment type*/
    public TextField appointmentTypeField;

    /**TextField for setting appointment customerId*/
    public ComboBox appointmentCustomerIdComboBox;

    /**ComboBox for setting appointment userId*/
    public ComboBox appointmentUserIdComboBox;

    /**DatePicker for setting appointment start date*/
    public DatePicker appointmentStartDatePicker;

    /**ComboBox for setting appointment start hour*/
    public ComboBox<String> appointmentStartHour;

    /**ComboBox for setting appointment start minute*/
    public ComboBox<String> appointmentStartMinute;

    /**Instant for setting UTC start instant*/
    public Instant utcStartInstant;

    /**DatePicker for setting appointment end date*/
    public DatePicker appointmentEndDatePicker;

    /**ComboBox for setting appointment end hour*/
    public ComboBox<String> appointmentEndHour;

    /**ComboBox for setting appointment end minute*/
    public ComboBox<String> appointmentEndMinute;

    /**Instant for setting UTC end instant*/
    public Instant utcEndInstant;


    /**
     * Method which populates combo boxes for field selection
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> contacts = FXCollections.observableArrayList();
        ObservableList<String> customers = FXCollections.observableArrayList();
        ObservableList<String> users = FXCollections.observableArrayList();

        ObservableList<String> hours = FXCollections.observableArrayList();
        ObservableList<String> minutes = FXCollections.observableArrayList();

        //Set ComboBoxes for start/end hours and minutes
        hours.addAll("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11",
                "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
        minutes.addAll("00", "15", "30", "45");

        appointmentStartHour.setItems(hours);
        appointmentStartMinute.setItems(minutes);
        appointmentEndHour.setItems(hours);
        appointmentEndMinute.setItems(minutes);

        //Fill contacts ChoiceBox
        Query.makeQuery("SELECT * FROM contacts");
        ResultSet result = Query.getResult();

        try {
            while (result.next()) {
                contacts.add(result.getString("Contact_Name"));
            }
        } catch(Exception e) {

        }

        //Fill customers ChoiceBox
        Query.makeQuery("SELECT * FROM customers");
        result = Query.getResult();

        try {
            while (result.next()) {
                customers.add(result.getString("Customer_ID"));
            }
        } catch(Exception e) {

        }

        //Fill users ChoiceBox
        Query.makeQuery("SELECT * FROM users");
        result = Query.getResult();

        try {
            while (result.next()) {
                users.add(result.getString("User_ID"));
            }
        } catch(Exception e) {

        }
        appointmentContactComboBox.setItems(contacts);
        appointmentCustomerIdComboBox.setItems(customers);
        appointmentUserIdComboBox.setItems(users);
    }

    /**
     * Method which validates and saves appointment record to DB
     * @param actionEvent
     * @throws IOException
     */
    public void onSaveAppointment(ActionEvent actionEvent) throws IOException {
        if (!(checkTitle() && checkDescription() && checkLocation() && checkContact() && checkType() && checkCustomerId() && checkUserId())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid field(s)");
            alert.setContentText("Please fill all fields correctly");
            alert.showAndWait();
            return;
        }
        //Prints separate alert from methods
        if (!(checkStartDateTime() && checkEndDateTime())) {
            return;
        }
        Timestamp start = Timestamp.from(utcStartInstant);
        Timestamp end = Timestamp.from(utcEndInstant);

        if (checkOverlapping(start, end)) {
            return;
        }

        try {
            int appointmentId = AppointmentsImplementation.getNextId();
            String title = appointmentTitleField.getText();
            String description = appointmentDescriptionField.getText();
            String location = appointmentLocationField.getText();
            String contactName = (String) appointmentContactComboBox.getSelectionModel().getSelectedItem();
            String type = appointmentTypeField.getText();
            int customerId = Integer.valueOf((String) appointmentCustomerIdComboBox.getSelectionModel().getSelectedItem());
            int userId = (int) Integer.valueOf((String) appointmentUserIdComboBox.getSelectionModel().getSelectedItem());

            Query.makeQuery("SELECT Contact_ID FROM contacts WHERE Contact_Name = '" + contactName + "'");
            ResultSet result = Query.getResult();
            result.next();
            int contactId = result.getInt("Contact_ID");

            Appointments a = new Appointments(appointmentId, title, description, location, type, start, end, customerId, userId, contactId);
            a.setContact(contactName);
            AppointmentsImplementation.add(a);
        } catch(Exception e) {

        }

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which cancels appointment creation and returns to Menu.fxml
     * @param actionEvent
     * @throws IOException
     */
    public void onCancelAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which validates title
     * @return true if valid
     */
    public boolean checkTitle() {
        if (appointmentTitleField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates description
     * @return true if valid
     */
    public boolean checkDescription() {
        if (appointmentDescriptionField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates location
     * @return true if valid
     */
    public boolean checkLocation() {
        if (appointmentLocationField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates contact
     * @return true if valid
     */
    public boolean checkContact() {
        if (appointmentContactComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates type
     * @return true if valid
     */
    public boolean checkType() {
        if (appointmentTypeField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates start
     * @return true if valid
     */
    public boolean checkStartDateTime() {
        if (appointmentStartDatePicker.getValue() == null || appointmentStartHour.getSelectionModel().getSelectedItem() == null || appointmentStartMinute.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        LocalDate date = appointmentStartDatePicker.getValue();
        String hour = appointmentStartHour.getSelectionModel().getSelectedItem();
        String minute = appointmentStartMinute.getSelectionModel().getSelectedItem();

        LocalDateTime localDateTime = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.valueOf(hour), Integer.valueOf(minute));
        Timestamp localTimestamp = Timestamp.valueOf(localDateTime);
        Instant localInstant = localTimestamp.toInstant();
        ZonedDateTime utcDateTimeZoned = ZonedDateTime.ofInstant(localInstant, ZoneId.of("UTC"));
        Instant utcInstant = utcDateTimeZoned.toInstant();

        //Create eastern time equivalent to check if within business hours
        ZonedDateTime easternDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.of("America/New_York"));
        LocalDateTime easternDateTime = Timestamp.from(easternDateTimeZoned.toInstant()).toLocalDateTime();

        //Time is outside of business hours
        if (easternDateTime.getHour() < 8 || easternDateTime.getHour() >= 22) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid start time");
            alert.setContentText("Please ensure time is within BUSINESS HOURS:\n\n" + "8:00 A.M. to 10:00 P.M. ET");
            alert.showAndWait();
            return false;
        }
        //Time is scheduled within business hours
        utcStartInstant = utcInstant;
        return true;
    }

    /**
     * Method which validates end
     * @return true if valid
     */
    public boolean checkEndDateTime() {
        if (appointmentEndDatePicker.getValue() == null || appointmentEndHour.getSelectionModel().getSelectedItem() == null || appointmentEndMinute.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        LocalDate date = appointmentEndDatePicker.getValue();
        String hour = appointmentEndHour.getSelectionModel().getSelectedItem();
        String minute = appointmentEndMinute.getSelectionModel().getSelectedItem();

        LocalDateTime localDateTime = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.valueOf(hour), Integer.valueOf(minute));
        Timestamp localTimestamp = Timestamp.valueOf(localDateTime);
        Instant localInstant = localTimestamp.toInstant();
        ZonedDateTime utcDateTimeZoned = ZonedDateTime.ofInstant(localInstant, ZoneId.of("UTC"));
        Instant utcInstant = utcDateTimeZoned.toInstant();

        //Create eastern time equivalent to check if within business hours
        ZonedDateTime easternDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.of("America/New_York"));
        LocalDateTime easternDateTime = Timestamp.from(easternDateTimeZoned.toInstant()).toLocalDateTime();

        //Time is outside of business hours
        if (easternDateTime.getHour() < 8
            || (easternDateTime.getHour() == 8 && easternDateTime.getMinute() < 15)
            || (easternDateTime.getHour() == 22 && easternDateTime.getMinute() > 0)
            || easternDateTime.getHour() > 22
            ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid end time");
            alert.setContentText("Please ensure time is within BUSINESS HOURS:\n\n" + "8:00 A.M. to 10:00 P.M. ET");
            alert.showAndWait();
            return false;
        }

        //Time is scheduled within business hours
        utcEndInstant = utcInstant;
        return true;
    }

    /**
     * Method which validates start and end times not overlapping
     * @return false if not overlapping
     */
    public boolean checkOverlapping(Timestamp start, Timestamp end) {
        //First, ensure that appointment starts and ends on same day
        //README: FOR FUTURE UPDATE, CREATE ONLY 1 BUTTON FOR APPOINTMENT DATE TO AVOID REDUNDANCY
        if (start.toLocalDateTime().getDayOfYear() != end.toLocalDateTime().getDayOfYear()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid start and end date");
            alert.setContentText("Appointment must start and end on the same day");
            alert.showAndWait();
            return true;
        }
        //Next, ensure appointment start comes before appointment end

        //Check that start hour is less than end hour
        if ((start.toLocalDateTime().getHour() > end.toLocalDateTime().getHour())
              //Check that if hours are same, end minutes must be greater
              || (start.toLocalDateTime().getHour() == end.toLocalDateTime().getHour()
              && start.toLocalDateTime().getMinute() >= end.toLocalDateTime().getMinute())
            ) {
            //Appointment start comes after end
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid start and end time");
            alert.setContentText("Appointment must end at least 15 minutes after start");
            alert.showAndWait();
            return true;
        }

        //Check if overlapping with other appointments
        ObservableList<Appointments> allAppointments = AppointmentsImplementation.getAllAppointments();
        LocalDateTime userStartLdt = start.toLocalDateTime();
        LocalDateTime userEndLdt = end.toLocalDateTime();


        for (Appointments a : allAppointments) {
            //Compares this appointment to all other appointments for overlap (comparing both in UTC)
            LocalDateTime listStartLdt = a.getStart().toLocalDateTime();
            LocalDateTime listEndLdt = a.getEnd().toLocalDateTime();

            //Appointments on same day, check times
            if (userStartLdt.getDayOfYear() == listEndLdt.getDayOfYear()) {
                //Starts after appointment ends
                if ((userStartLdt.getHour() == listEndLdt.getHour() && userStartLdt.getMinute() >= listEndLdt.getMinute())
                    || (userStartLdt.getHour() > listEndLdt.getHour())) {
                    //Valid for single appointment comparison, continue checking rest
                }
                //Otherwise, ends before appointment starts
                else if ((userEndLdt.getHour() == listStartLdt.getHour() && userEndLdt.getMinute() <= listStartLdt.getMinute())
                         || (userEndLdt.getHour() < listStartLdt.getHour())) {
                    //Valid for single appointment comparison, continue checking rest
                }
                else {
                    //Invalid for an appointment, cannot book for this time
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("ERROR");
                    alert.setHeaderText("Invalid date and time");
                    alert.setContentText("An appointment is already booked for this date and time");
                    alert.showAndWait();
                    return true;
                }
            }
            //Appointments on different days, no need to check times
            else {

            }
        }
        return false;
    }

    /**
     * Method which validates customerId
     * @return true if valid
     */
    public boolean checkCustomerId() {
        if (appointmentCustomerIdComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates userId
     * @return true if valid
     */
    public boolean checkUserId() {
        if (appointmentUserIdComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }
}
