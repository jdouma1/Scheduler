package controller;

import DAO.CustomersImplementation;
import DAO.Query;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Customers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;


/**
 * UpdateCustomersController is a controller class for viewing and updating customer records in DB
 *
 * @author Jacob Douma
 */
public class UpdateCustomersController implements Initializable {

    /**Disabled TextField for viewing customer ID*/
    public TextField customerIdField;

    /**TextField for viewing and updating customer name*/
    public TextField customerNameField;

    /**TextField for viewing and updating customer Address*/
    public TextField customerAddressField;

    /**TextField for viewing and updating customer PostalCode*/
    public TextField customerPostalCodeField;

    /**TextField for viewing and updating customer PhoneNumber*/
    public TextField customerPhoneNumberField;

    /**ComboBox for viewing and updating customer firstLevelDivision*/
    public ComboBox firstLevelDivisionComboBox;

    /**ComboBox for viewing and updating customer country*/
    public ComboBox countryComboBox;

    /**Label for signaling country must be selected before first level division*/
    public Label unselectedCountryLabel;

    /**Object to store selected customer for viewing and updating*/
    private static Customers customer;

    /**Object to store selected divisionId for finding firstLevelDivision*/
    private static int divisionId;

    /**Object to store selected firstLevelDivision for viewing and updating*/
    private static String firstLevelDivision;

    /**Object to store selected country for viewing and updating*/
    private static String country;


    /**
     * Method which initializes customer info to selected customer
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Initialize Country ChoiceBox
        ObservableList<String> countries = FXCollections.observableArrayList();

        Query.makeQuery("SELECT * FROM countries");
        ResultSet result = Query.getResult();

        try {
            while (result.next()) {
                countries.add(result.getString("Country"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        countryComboBox.setItems(countries);
        countryComboBox.setValue(country);

        //Initialize First-Level-Division ChoiceBox from CountryID
        ObservableList<String> division = FXCollections.observableArrayList();

        String country = (String) countryComboBox.getSelectionModel().getSelectedItem();
        Query.makeQuery("SELECT * FROM countries WHERE Country = '" + country + "'");
        result = Query.getResult();

        try {
            result.next();
            String countryId = result.getString("Country_ID");
            Query.makeQuery("SELECT * FROM first_level_divisions WHERE Country_ID = '" + countryId + "'");
            result = Query.getResult();

            while (result.next()) {
                division.add(result.getString("Division"));
            }
            firstLevelDivisionComboBox.setItems(division);
            firstLevelDivisionComboBox.setValue(firstLevelDivision);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        customerIdField.setText(String.valueOf(customer.getId()));
        customerNameField.setText(customer.getName());
        customerAddressField.setText(customer.getAddress());
        customerPostalCodeField.setText(customer.getPostalCode());
        customerPhoneNumberField.setText(customer.getPhone());
    }

    /**
     * Method which stores selected customer, firstLevelDivision, and country data for populating fields
     * @param c
     * @throws SQLException
     */
    public static void generateCustomer(Customers c) throws SQLException {
        customer = c;
        String countryId;

        Query.makeQuery("SELECT Division FROM first_level_divisions WHERE Division_ID = '" + c.getDivisionId() + "'");
        ResultSet result = Query.getResult();
        result.next();
        firstLevelDivision = result.getString("Division");

        Query.makeQuery("SELECT Country_ID FROM first_level_divisions WHERE Division = '" + firstLevelDivision + "'");
        result = Query.getResult();
        result.next();
        countryId = result.getString("Country_ID");

        Query.makeQuery("SELECT Country FROM countries WHERE Country_ID = '" + countryId + "'");
        result = Query.getResult();
        result.next();
        country = result.getString("Country");
    }

    /**
     * Method which validates fields and updates customer
     * @param actionEvent
     * @throws IOException
     * @throws SQLException
     */
    public void onUpdateCustomer(ActionEvent actionEvent) throws IOException, SQLException {
        if (!(checkName() && checkAddress() && checkPostalCode() && checkPhoneNumber() && checkCountry() && checkFirstLevelDivision())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid field(s)");
            alert.setContentText("Please fill all fields");
            alert.showAndWait();
            return;
        }

        try {
            String division = (String) firstLevelDivisionComboBox.getSelectionModel().getSelectedItem();
            String query = "SELECT Division_ID FROM first_level_divisions WHERE Division = '" + division + "'";
            Query.makeQuery(query);
            ResultSet result = Query.getResult();
            result.next();

            int id = Integer.valueOf(customerIdField.getText());
            String name = customerNameField.getText();
            String address = customerAddressField.getText();
            String postalCode = customerPostalCodeField.getText();
            String phone = customerPhoneNumberField.getText();
            int divisionId = Integer.valueOf(result.getString("Division_ID"));
            Customers c = new Customers(id, name, address, postalCode, phone, divisionId);

            CustomersImplementation.update(id, c);
        } catch(Exception e) {

        }

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which cancels update and returns to Menu
     * @param actionEvent
     * @throws IOException
     */
    public void onCancelCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which validates country has been selected and sets country and firstLevelDivision
     * @param mouseEvent
     * @throws SQLException
     */
    public void onSelectedDivision(MouseEvent mouseEvent) throws SQLException {
        //Initialize First-Level-Division ChoiceBox from CountryID

        if (!checkCountry()) {
            unselectedCountryLabel.setVisible(true);
            return;
        }
        unselectedCountryLabel.setVisible(false);
        ObservableList<String> division = FXCollections.observableArrayList();

        String country = (String) countryComboBox.getSelectionModel().getSelectedItem();
        Query.makeQuery("SELECT * FROM countries WHERE Country = '" + country + "'");
        ResultSet result = Query.getResult();
        result.next();

        String countryId = result.getString("Country_ID");
        Query.makeQuery("SELECT * FROM first_level_divisions WHERE Country_ID = '" + countryId + "'");
        result = Query.getResult();

        try {
            while (result.next()) {
                division.add(result.getString("Division"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        firstLevelDivisionComboBox.setItems(division);
    }

    /**
     * Method which validates name
     * @return true if valid
     */
    public boolean checkName() {
        if (customerNameField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates address
     * @return true if valid
     */
    public boolean checkAddress() {
        if (customerAddressField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates postal code
     * @return true if valid
     */
    public boolean checkPostalCode() {
        if (customerPostalCodeField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates phone number
     * @return true if valid
     */
    public boolean checkPhoneNumber() {
        if (customerPhoneNumberField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates country
     * @return true if valid
     */
    public boolean checkCountry() {
        if (countryComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates firstLevelDivision
     * @return true if valid
     */
    public boolean checkFirstLevelDivision() {
        if (firstLevelDivisionComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }
}
