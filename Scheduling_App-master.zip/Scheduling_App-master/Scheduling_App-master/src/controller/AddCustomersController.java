package controller;

import DAO.CustomersImplementation;
import DAO.Query;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Customers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;


/**
 * AddCustomersController is a controller class for adding customer records to DB
 *
 * @author Jacob Douma
 */
public class AddCustomersController implements Initializable {

    /**Disabled TextField for viewing customer ID*/
    public TextField customerIdField;

    /**TextField for setting customer name*/
    public TextField customerNameField;

    /**TextField for setting customer address*/
    public TextField customerAddressField;

    /**TextField for setting customer postalCode*/
    public TextField customerPostalCodeField;

    /**TextField for setting customer phoneNumber*/
    public TextField customerPhoneNumberField;

    /**ComboBox for setting customer firstLevelDivision*/
    public ComboBox firstLevelDivisionComboBox;

    /**ComboBox for setting customer country*/
    public ComboBox countryComboBox;

    /**Label for informing country is unselected*/
    public Label unselectedCountryLabel;


    /**
     * Method which populates firstLevelDivision and country combo boxes
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Initialize Country ChoiceBox
        ObservableList<String> countries = FXCollections.observableArrayList();

        Query.makeQuery("SELECT * FROM countries");
        ResultSet result = Query.getResult();

        try {
            while (result.next()) {
                countries.add(result.getString("Country"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        countryComboBox.setItems(countries);
    }

    /**
     * Method which validates and adds customer record to DB
     * @param actionEvent
     * @throws IOException
     * @throws SQLException
     */
    public void onSaveCustomer(ActionEvent actionEvent) throws IOException, SQLException {
        if (!(checkName() && checkAddress() && checkPostalCode() && checkPhoneNumber() && checkCountry() && checkFirstLevelDivision())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid field(s)");
            alert.setContentText("Please fill all fields");
            alert.showAndWait();
            return;
        }

        String division = (String) firstLevelDivisionComboBox.getSelectionModel().getSelectedItem();
        String query = "SELECT Division_ID FROM first_level_divisions WHERE Division = '" + division + "'";
        Query.makeQuery(query);
        ResultSet result = Query.getResult();
        result.next();

        int id = CustomersImplementation.getNextId();
        String name = customerNameField.getText();
        String address = customerAddressField.getText();
        String postalCode = customerPostalCodeField.getText();
        String phone = customerPhoneNumberField.getText();
        int divisionId = Integer.valueOf(result.getString("Division_ID"));
        CustomersImplementation.add(new Customers(id, name, address, postalCode, phone, divisionId));

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which cancels action of adding customer and returns to Menu.fxml
     * @param actionEvent
     * @throws IOException
     */
    public void onCancelCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which ensures country is selected, then selects firstLevelDivision
     * @param mouseEvent
     * @throws SQLException
     */
    public void onSelectedDivision(MouseEvent mouseEvent) throws SQLException {
        //Initialize First-Level-Division ChoiceBox from CountryID

        if (countryComboBox.getSelectionModel().getSelectedItem() == null) {
            unselectedCountryLabel.setVisible(true);
            return;
        }
        unselectedCountryLabel.setVisible(false);
        ObservableList<String> division = FXCollections.observableArrayList();

        String country = (String) countryComboBox.getSelectionModel().getSelectedItem();
        Query.makeQuery("SELECT * FROM countries WHERE Country = '" + country + "'");
        ResultSet result = Query.getResult();
        result.next();

        String countryId = result.getString("Country_ID");
        Query.makeQuery("SELECT * FROM first_level_divisions WHERE Country_ID = '" + countryId + "'");
        result = Query.getResult();

        try {
            while (result.next()) {
                division.add(result.getString("Division"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        firstLevelDivisionComboBox.setItems(division);
    }

    /**
     * Method which validates name
     * @return true if valid
     */
    public boolean checkName() {
        if (customerNameField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates address
     * @return true if valid
     */
    public boolean checkAddress() {
        if (customerAddressField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates postal code
     * @return true if valid
     */
    public boolean checkPostalCode() {
        if (customerPostalCodeField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates phone number
     * @return true if valid
     */
    public boolean checkPhoneNumber() {
        if (customerPhoneNumberField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates country
     * @return true if valid
     */
    public boolean checkCountry() {
        if (countryComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates firstLevelDivision
     * @return true if valid
     */
    public boolean checkFirstLevelDivision() {
        if (firstLevelDivisionComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }
}
