package controller;

import DAO.AppointmentsImplementation;
import DAO.Query;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.*;


/**
 * ReportsController is a controller class for viewing reports on Scheduling App DB
 *
 * @author Jacob Douma
 */
public class ReportsController implements Initializable {

    /**TextArea for displaying total customer appointments*/
    public TextArea customerAppointmentsTextArea;

    /**ComboBox for switching contacts to display schedule*/
    public ComboBox<String> contactComboBox;

    /**TableView for displaying contact schedule*/
    public TableView contactScheduleTable;

    /**TableColumn for displaying appointmentId*/
    public TableColumn appointmentIdColumn;

    /**TableColumn for displaying title*/
    public TableColumn titleColumn;

    /**TableColumn for displaying type*/
    public TableColumn typeColumn;

    /**TableColumn for displaying description*/
    public TableColumn descriptionColumn;

    /**TableColumn for displaying start*/
    public TableColumn startColumn;

    /**TableColumn for displaying end*/
    public TableColumn endColumn;

    /**TableColumn for displaying customerId*/
    public TableColumn customerIdColumn;

    /**List of appointments for contact's schedule*/
    private List<Appointments> contactAppointments = FXCollections.emptyObservableList();

    /**List of contact's to choose for displaying schedule*/
    private ObservableList<Contacts> allContacts = FXCollections.observableArrayList();

    /**Index to track which contact's schedule to display*/
    private int currentContactId = 1;


    /**
     * Method which initializes total customer appointments TextArea and contact schedule table
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initializeTotalCustomerAppointments();
        initializeContactSchedules();
    }

    /**
     * Method which initializes total customer appointments TextArea
     */
    public void initializeTotalCustomerAppointments() {
        //Initialize TextArea for Total Customer Appointments by Type and Month
        HashMap<String, Integer> appointmentsByType = AppointmentsImplementation.getAppointmentsByType();
        HashMap<String, Integer> appointmentsByMonth = AppointmentsImplementation.getAppointmentsByMonth();

        String customerAppointmentsRecord = "APPOINTMENTS BY TYPE:\n";

        Iterator hmIterator = appointmentsByType.entrySet().iterator();
        while (hmIterator.hasNext()) {
            Map.Entry pair = (Map.Entry)hmIterator.next();
            customerAppointmentsRecord = customerAppointmentsRecord.concat("\n" + pair.getKey() + ": " + pair.getValue());
        }
        customerAppointmentsRecord = customerAppointmentsRecord.concat("\n\n\nAPPOINTMENTS BY MONTH:\n");

        hmIterator = appointmentsByMonth.entrySet().iterator();
        while (hmIterator.hasNext()) {
            Map.Entry pair = (Map.Entry)hmIterator.next();
            customerAppointmentsRecord = customerAppointmentsRecord.concat("\n" + pair.getKey() + ": " + pair.getValue());
        }

        customerAppointmentsTextArea.setText(customerAppointmentsRecord);
    }

    /**
     * <p>Method which initializes contact schedule table.</p>
     * <p>Uses lambda to easily stream and filter to collect appointments with matching contact IDs.</p>
     */
    public void initializeContactSchedules() {
        //Fill Contacts ChoiceBox and Populate table for default contact
        Query.makeQuery("SELECT * FROM contacts");
        ResultSet result = Query.getResult();
        ObservableList<String> allContactNames = FXCollections.observableArrayList();

        try {
            while (result.next()) {
                int id = result.getInt("Contact_ID");
                String name = result.getString("Contact_Name");
                String email = result.getString("Email");
                Contacts contact = new Contacts(id, name, email);

                //Add names for ChoiceBox list and ID for populating table
                //with Appointments containing matching Contact IDs
                allContactNames.add(name);
                allContacts.add(contact);
            }
            contactComboBox.setItems(allContactNames);
            contactComboBox.setValue(allContactNames.get(0));

            //USED LAMBDA EXPRESSION
            //Filter displayed appointments by matching Contact ID
            contactAppointments = AppointmentsImplementation.getAllAppointments()
                    .stream()
                    .filter(a -> a.getContactId() == currentContactId)
                    .toList();

            //Initialize table to default contact
            appointmentIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
            titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
            typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
            descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
            startColumn.setCellValueFactory(new PropertyValueFactory<>("startLocal"));
            endColumn.setCellValueFactory(new PropertyValueFactory<>("endLocal"));
            customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
            contactScheduleTable.setItems(FXCollections.observableArrayList(contactAppointments));

        } catch(Exception e) {

        }
    }

    /**
     * Method which displays table of contact selected
     * @param actionEvent
     */
    public void onSelectedContact(ActionEvent actionEvent) {
        String contactName = contactComboBox.getValue();

        for (Contacts c : allContacts) {
            if (c.getContactName().equals(contactName)) {
                //Set currentContactId to name fetched from searching matching name
                currentContactId = c.getContactId();
            }
        }
        //Filter displayed appointments by matching Contact ID
        contactAppointments = AppointmentsImplementation.getAllAppointments()
                .stream()
                .filter(a -> a.getContactId() == currentContactId)
                .toList();
        contactScheduleTable.setItems(FXCollections.observableArrayList(contactAppointments));
    }

    /**
     * Method which displays DeletedRecordsReport page of deleted records
     * @param actionEvent
     * @throws IOException
     */
    public void onSelectedDeletedRecords(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/DeletedRecordsReport.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which returns to Menu
     * @param actionEvent
     * @throws IOException
     */
    public void onExitReports(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
