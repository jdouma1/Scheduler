package controller;

import DAO.LoginAttemptsImplementation;
import DAO.UserImplementation;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.LoginAttempts;
import model.Users;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.ResourceBundle;


/**
 * LoginController is a controller class for displaying the Login form, validating login information, and tracking login attempts
 *
 * @author Jacob Douma
 */
public class LoginController implements Initializable {
    public Label welcomeLabel;
    public Label usernameLabel;
    public Label passwordLabel;

    /**Button for logging in*/
    public Button loginButton;

    /**Label which displays Zone ID*/
    public Label zoneId;

    /**TextField for inputting username*/
    public TextField usernameField;

    /**PasswordField for inputting password*/
    public PasswordField passwordField;


    /**
     * Method which initializes form in appropriate language depending on locale
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //For user default zone and locale
        ZoneId userZoneId = ZoneId.systemDefault();
        ResourceBundle rb = ResourceBundle.getBundle("Utilities/Language", Locale.getDefault());
        //Test for French
        //ZoneId userZoneId = ZoneId.of("Europe/Paris");
        //ResourceBundle rb = ResourceBundle.getBundle("Utilities/Language", Locale.FRENCH);

        if (rb.getLocale() == Locale.FRENCH || rb.getLocale() == Locale.ENGLISH) {
            welcomeLabel.setText(rb.getString("WELCOME"));
            usernameLabel.setText(rb.getString("USERNAME"));
            passwordLabel.setText(rb.getString("PASSWORD"));
            loginButton.setText(rb.getString("LOGIN"));
            zoneId.setText(rb.getString("ZONE") + " " + rb.getString("ID") + " :  " + userZoneId.getId());
        }
    }

    /**
     * Method which validates username and password, tracks login attempts, and switches to Menu.fxml
     * @param event
     * @throws IOException
     * @throws SQLException
     */
    public void onLogin(ActionEvent event) throws IOException, SQLException {
        Users testUser = UserImplementation.getUser("test");
        Users adminUser = UserImplementation.getUser("admin");

        if (usernameField.getText().isBlank() ||
            passwordField.getText().isBlank() ||
            (!usernameField.getText().equals(testUser.getUsername()) && !usernameField.getText().equals(adminUser.getUsername())) ||
            (usernameField.getText().equals(testUser.getUsername())) && !passwordField.getText().equals(testUser.getPassword()) ||
            (usernameField.getText().equals(adminUser.getUsername())) && !passwordField.getText().equals(adminUser.getPassword()))
        {
            String username = "";
            if (!usernameField.getText().isBlank()) {
                username = usernameField.getText();
            }
            Instant localInstant = Instant.now();
            ZonedDateTime utcZoned = ZonedDateTime.ofInstant(localInstant, ZoneId.of("UTC"));
            Timestamp utcTimestamp = Timestamp.from(utcZoned.toInstant());
            boolean successful = false;

            LoginAttempts attempt = new LoginAttempts(username, utcTimestamp, successful);
            LoginAttemptsImplementation.addLoginAttempt(attempt);


            Alert alert = new Alert(Alert.AlertType.ERROR);
            ResourceBundle rb = ResourceBundle.getBundle("Utilities/Language", Locale.getDefault());
            if (rb.getLocale() == Locale.FRENCH || rb.getLocale() == Locale.ENGLISH) {
                alert.setTitle(rb.getString("FAILEDLOGIN"));
                alert.setHeaderText(rb.getString("ERROR"));
                alert.setContentText(rb.getString("InvalidLoginInformation"));
                ((Button) alert.getDialogPane().lookupButton(ButtonType.OK)).setText(rb.getString("OK"));
            }
            alert.show();
        }
        else {
            String username = usernameField.getText();
            Instant localInstant = Instant.now();
            ZonedDateTime utcZoned = ZonedDateTime.ofInstant(localInstant, ZoneId.of("UTC"));
            Timestamp utcTimestamp = Timestamp.from(utcZoned.toInstant());
            boolean successful = true;

            LoginAttempts attempt = new LoginAttempts(username, utcTimestamp, successful);
            LoginAttemptsImplementation.addLoginAttempt(attempt);


            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }
}
