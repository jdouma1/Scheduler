package controller;

import DAO.AppointmentsImplementation;
import DAO.CustomersImplementation;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


/**
 * DeletedRecordsReport is a controller class for viewing Reports on deleted records
 *
 * @author Jacob Douma
 */
public class DeletedRecordsReport implements Initializable {

    /**TableView for displaying deleted customers*/
    public TableView deletedCustomersTable;
    //public TableColumn customersIdColumn;

    /**TableColumn for displaying customerName*/
    public TableColumn customersNameColumn;

    /**TableColumn for displaying customerAddress*/
    public TableColumn customersAddressColumn;

    /**TableColumn for displaying customer*/
    public TableColumn customersPostalCodeColumn;

    /**TableColumn for displaying customerPhone*/
    public TableColumn customersPhoneColumn;

    /**TableColumn for displaying customerDivisionId*/
    public TableColumn customersDivisionIdColumn;

    /**TableColumn for displaying customer deletion Timestamp*/
    public TableColumn customersDeletedColumn;

    /**TableView for displaying deleted appointments*/
    public TableView deletedAppointmentsTable;
    //public TableColumn appointmentsIdColumn;

    /**TableColumn for displaying appointmentTitle*/
    public TableColumn appointmentsTitleColumn;

    /**TableColumn for displaying appointmentDescription*/
    public TableColumn appointmentsDescriptionColumn;

    /**TableColumn for displaying appointmentLocation*/
    public TableColumn appointmentsLocationColumn;

    /**TableColumn for displaying appointmentContact*/
    public TableColumn appointmentsContactColumn;

    /**TableColumn for displaying appointmentType*/
    public TableColumn appointmentsTypeColumn;

    /**TableColumn for displaying appointmentStart*/
    public TableColumn appointmentsStartColumn;

    /**TableColumn for displaying appointmentEnd*/
    public TableColumn appointmentsEndColumn;

    /**TableColumn for displaying appointmentCustomerId*/
    public TableColumn appointmentsCustomerIdColumn;

    /**TableColumn for displaying appointmentUserId*/
    public TableColumn appointmentsUserIdColumn;

    /**TableColumn for displaying appointmentDeleted*/
    public TableColumn appointmentsDeletedColumn;


    /**
     * Method which sets customer and appointment tables
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //customersIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        customersNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        customersAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        customersPostalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        customersPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        customersDivisionIdColumn.setCellValueFactory(new PropertyValueFactory<>("divisionId"));
        customersDeletedColumn.setCellValueFactory(new PropertyValueFactory<>("deletedTimestampLocal"));
        deletedCustomersTable.setItems(CustomersImplementation.getAllDeletedCustomers());

        //appointmentsIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        appointmentsTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        appointmentsDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        appointmentsLocationColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        appointmentsContactColumn.setCellValueFactory(new PropertyValueFactory<>("contact"));
        appointmentsTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        appointmentsStartColumn.setCellValueFactory(new PropertyValueFactory<>("startLocal"));
        appointmentsEndColumn.setCellValueFactory(new PropertyValueFactory<>("endLocal"));
        appointmentsCustomerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        appointmentsUserIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        appointmentsDeletedColumn.setCellValueFactory(new PropertyValueFactory<>("deletedTimestampLocal"));
        deletedAppointmentsTable.setItems(AppointmentsImplementation.getAllDeletedAppointments());
    }

    /**
     * Method which returns to Reports.fxml
     * @param actionEvent
     * @throws IOException
     */
    public void onBack(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Reports.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
