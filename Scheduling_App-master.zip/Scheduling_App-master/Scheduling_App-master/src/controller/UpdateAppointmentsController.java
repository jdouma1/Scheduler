package controller;

import DAO.AppointmentsImplementation;
import DAO.Query;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.*;
import java.util.ResourceBundle;


/**
 * UpdateAppointmentsController is a controller class for viewing and updating appointment records in DB
 *
 * @author Jacob Douma
 */
public class UpdateAppointmentsController implements Initializable {

    /**Disabled TextField for viewing appointmentId*/
    public TextField appointmentIdField;

    /**TextField for viewing and updating appointment title*/
    public TextField appointmentTitleField;

    /**TextField for viewing and updating appointment description*/
    public TextField appointmentDescriptionField;

    /**TextField for viewing and updating appointment location*/
    public TextField appointmentLocationField;

    /**ComboBox for viewing and updating appointment contact*/
    public ComboBox appointmentContactComboBox;

    /**TextField for viewing and updating appointment type*/
    public TextField appointmentTypeField;

    /**ComboBox for viewing and updating appointment customerId*/
    public ComboBox appointmentCustomerIdComboBox;

    /**ComboBox for viewing and updating appointment title*/
    public ComboBox appointmentUserIdComboBox;

    /**DatePicker for viewing and updating appointment start date*/
    public DatePicker appointmentStartDatePicker;

    /**ComboBox for viewing and updating appointment start hour*/
    public ComboBox<String> appointmentStartHour;

    /**ComboBox for viewing and updating appointment start minute*/
    public ComboBox<String> appointmentStartMinute;

    /**Instant for create start Timestamp in UTC*/
    public Instant utcStartInstant;

    /**DatePicker for viewing and updating appointment end date*/
    public DatePicker appointmentEndDatePicker;

    /**ComboBox for viewing and updating appointment end hour*/
    public ComboBox<String> appointmentEndHour;

    /**ComboBox for viewing and updating appointment end minute*/
    public ComboBox<String> appointmentEndMinute;

    /**Instant for create end Timestamp in UTC*/
    public Instant utcEndInstant;

    /**Object to store selected appointment for viewing and updating*/
    private static Appointments appointment;


    /**
     * Method which initializes appointment info to selected appointment
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> contacts = FXCollections.observableArrayList();
        ObservableList<String> customers = FXCollections.observableArrayList();
        ObservableList<String> users = FXCollections.observableArrayList();

        ObservableList<String> hours = FXCollections.observableArrayList();
        ObservableList<String> minutes = FXCollections.observableArrayList();

        //Set ComboBoxes for start/end hours and minutes
        hours.addAll("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11",
                "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
        minutes.addAll("00", "15", "30", "45");

        appointmentStartHour.setItems(hours);
        appointmentStartMinute.setItems(minutes);
        appointmentEndHour.setItems(hours);
        appointmentEndMinute.setItems(minutes);

        //Fill contacts ChoiceBox
        Query.makeQuery("SELECT * FROM contacts");
        ResultSet result = Query.getResult();

        try {
            while (result.next()) {
                contacts.add(result.getString("Contact_Name"));
            }
        } catch(Exception e) {

        }

        //Fill customers ChoiceBox
        Query.makeQuery("SELECT * FROM customers");
        result = Query.getResult();

        try {
            while (result.next()) {
                customers.add(result.getString("Customer_ID"));
            }
        } catch(Exception e) {

        }

        //Fill users ChoiceBox
        Query.makeQuery("SELECT * FROM users");
        result = Query.getResult();

        try {
            while (result.next()) {
                users.add(result.getString("User_ID"));
            }
        } catch(Exception e) {

        }
        appointmentContactComboBox.setItems(contacts);
        appointmentCustomerIdComboBox.setItems(customers);
        appointmentUserIdComboBox.setItems(users);

        appointmentIdField.setText(String.valueOf(appointment.getAppointmentId()));
        appointmentTitleField.setText(appointment.getTitle());
        appointmentDescriptionField.setText(appointment.getDescription());
        appointmentLocationField.setText(appointment.getLocation());
        appointmentContactComboBox.setValue(String.valueOf(appointment.getContact()));
        appointmentTypeField.setText(appointment.getType());
        appointmentCustomerIdComboBox.setValue(String.valueOf(appointment.getCustomerId()));
        appointmentUserIdComboBox.setValue(String.valueOf(appointment.getUserId()));
        //Start
        Instant utcStartInstant = appointment.getStart().toInstant();
        ZonedDateTime startDateTimeZoned = ZonedDateTime.ofInstant(utcStartInstant, ZoneId.systemDefault());

        appointmentStartDatePicker.setValue(startDateTimeZoned.toLocalDate());
        appointmentStartHour.setValue(String.valueOf(startDateTimeZoned.getHour()));
        appointmentStartMinute.setValue(String.valueOf(startDateTimeZoned.getMinute()));
        //End
        Instant utcEndInstant = appointment.getEnd().toInstant();
        ZonedDateTime endDateTimeZoned = ZonedDateTime.ofInstant(utcEndInstant, ZoneId.systemDefault());

        appointmentEndDatePicker.setValue(endDateTimeZoned.toLocalDate());
        appointmentEndHour.setValue(String.valueOf(endDateTimeZoned.getHour()));
        appointmentEndMinute.setValue(String.valueOf(endDateTimeZoned.getMinute()));
    }

    /**
     * Method which stores selected appointment
     * @param a
     */
    public static void generateAppointment(Appointments a) {
        appointment = a;
    }

    /**
     * Method which validates fields and updates appointment
     * @param actionEvent
     * @throws IOException
     */
    public void onUpdateAppointment(ActionEvent actionEvent) throws IOException {
        if (!(checkTitle() && checkDescription() && checkLocation() && checkContact() && checkType() && checkCustomerId() && checkUserId())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid field(s)");
            alert.setContentText("Please fill all fields correctly");
            alert.showAndWait();
            return;
        }
        if (!(checkStartDateTime() && checkEndDateTime())) {
            return;
        }
        Timestamp start = Timestamp.from(utcStartInstant);
        Timestamp end = Timestamp.from(utcEndInstant);

        if (checkOverlapping(start, end)) {
            return;
        }

        try {
            int appointmentId = Integer.valueOf(appointmentIdField.getText());
            String title = appointmentTitleField.getText();
            String description = appointmentDescriptionField.getText();
            String location = appointmentLocationField.getText();
            String contactName = (String) appointmentContactComboBox.getSelectionModel().getSelectedItem();
            String type = appointmentTypeField.getText();
            int customerId = Integer.valueOf((String) appointmentCustomerIdComboBox.getSelectionModel().getSelectedItem());
            int userId = Integer.valueOf((String) appointmentUserIdComboBox.getSelectionModel().getSelectedItem());

            Query.makeQuery("SELECT Contact_ID FROM contacts WHERE Contact_Name = '" + contactName + "'");
            ResultSet result = Query.getResult();
            result.next();
            int contactId = result.getInt("Contact_ID");

            Appointments a = new Appointments(appointmentId, title, description, location, type, start, end, customerId, userId, contactId);
            a.setContact(contactName);
            AppointmentsImplementation.update(appointmentId, a);
        } catch(Exception e) {

        }

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which cancels update and returns to Menu
     * @param actionEvent
     * @throws IOException
     */
    public void onCancelAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../view/Menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method which validates title
     * @return true if valid
     */
    public boolean checkTitle() {
        if (appointmentTitleField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates description
     * @return true if valid
     */
    public boolean checkDescription() {
        if (appointmentDescriptionField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates location
     * @return true if valid
     */
    public boolean checkLocation() {
        if (appointmentLocationField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates contact
     * @return true if valid
     */
    public boolean checkContact() {
        if (appointmentContactComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates type
     * @return true if valid
     */
    public boolean checkType() {
        if (appointmentTypeField.getText().isBlank()) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates start
     * @return true if valid
     */
    public boolean checkStartDateTime() {
        if (appointmentStartDatePicker.getValue() == null || appointmentStartHour.getSelectionModel().getSelectedItem() == null || appointmentStartMinute.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        LocalDate date = appointmentStartDatePicker.getValue();
        String hour = appointmentStartHour.getSelectionModel().getSelectedItem();
        String minute = appointmentStartMinute.getSelectionModel().getSelectedItem();

        LocalDateTime localDateTime = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.valueOf(hour), Integer.valueOf(minute));
        Timestamp localTimestamp = Timestamp.valueOf(localDateTime);
        Instant localInstant = localTimestamp.toInstant();
        ZonedDateTime utcDateTimeZoned = ZonedDateTime.ofInstant(localInstant, ZoneId.of("UTC"));
        Instant utcInstant = utcDateTimeZoned.toInstant();

        //Create eastern time equivalent to check if within business hours
        ZonedDateTime easternDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.of("America/New_York"));
        LocalDateTime easternDateTime = Timestamp.from(easternDateTimeZoned.toInstant()).toLocalDateTime();

        //Time is outside of business hours
        if (easternDateTime.getHour() < 8 || easternDateTime.getHour() >= 22) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid start time");
            alert.setContentText("Please ensure time is within BUSINESS HOURS:\n\n" + "8:00 A.M. to 10:00 P.M. ET");
            alert.showAndWait();
            return false;
        }
        //Time is scheduled within business hours
        utcStartInstant = utcInstant;
        return true;
    }

    /**
     * Method which validates end
     * @return true if valid
     */
    public boolean checkEndDateTime() {
        if (appointmentEndDatePicker.getValue() == null || appointmentEndHour.getSelectionModel().getSelectedItem() == null || appointmentEndMinute.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        LocalDate date = appointmentEndDatePicker.getValue();
        String hour = appointmentEndHour.getSelectionModel().getSelectedItem();
        String minute = appointmentEndMinute.getSelectionModel().getSelectedItem();

        LocalDateTime localDateTime = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.valueOf(hour), Integer.valueOf(minute));
        Timestamp localTimestamp = Timestamp.valueOf(localDateTime);
        Instant localInstant = localTimestamp.toInstant();
        ZonedDateTime utcDateTimeZoned = ZonedDateTime.ofInstant(localInstant, ZoneId.of("UTC"));
        Instant utcInstant = utcDateTimeZoned.toInstant();

        //Create eastern time equivalent to check if within business hours
        ZonedDateTime easternDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.of("America/New_York"));
        LocalDateTime easternDateTime = Timestamp.from(easternDateTimeZoned.toInstant()).toLocalDateTime();

        //Time is outside of business hours
        if (easternDateTime.getHour() < 8
                || (easternDateTime.getHour() == 8 && easternDateTime.getMinute() < 15)
                || (easternDateTime.getHour() == 22 && easternDateTime.getMinute() > 0)
                || easternDateTime.getHour() > 22
        ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid end time");
            alert.setContentText("Please ensure time is within BUSINESS HOURS:\n\n" + "8:00 A.M. to 10:00 P.M. ET");
            alert.showAndWait();
            return false;
        }
        //Time is scheduled within business hours
        utcEndInstant = utcInstant;
        return true;
    }

    /**
     * Method which validates start and end times not overlapping
     * @param start
     * @param end
     * @return false if not overlapping
     */
    public boolean checkOverlapping(Timestamp start, Timestamp end) {
        //First, ensure that appointment starts and ends on same day
        //README: FOR FUTURE UPDATE, CREATE ONLY 1 BUTTON FOR APPOINTMENT DATE TO AVOID REDUNDANCY
        if (start.toLocalDateTime().getDayOfYear() != end.toLocalDateTime().getDayOfYear()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid start and end date");
            alert.setContentText("Appointment must start and end on the same day");
            alert.showAndWait();
            return true;
        }
        //Next, ensure appointment start comes before appointment end

        //Check that start hour is less than end hour
        if ((start.toLocalDateTime().getHour() > end.toLocalDateTime().getHour())
                //Check that if hours are same, end minutes must be greater
                || (start.toLocalDateTime().getHour() == end.toLocalDateTime().getHour()
                && start.toLocalDateTime().getMinute() >= end.toLocalDateTime().getMinute())
        ) {
            //Appointment start comes after end
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Invalid start and end time");
            alert.setContentText("Appointment must end at least 15 minutes after start");
            alert.showAndWait();
            return true;
        }

        //Check if overlapping with other appointments
        ObservableList<Appointments> allAppointments = AppointmentsImplementation.getAllAppointments();
        LocalDateTime userStartLdt = start.toLocalDateTime();
        LocalDateTime userEndLdt = end.toLocalDateTime();


        for (Appointments a : allAppointments) {
            //Ensures comparing different appointments
            if (a.getAppointmentId() != appointment.getAppointmentId()) {

                //Compares this appointment to all other appointments for overlap (comparing both in UTC)
                LocalDateTime listStartLdt = a.getStart().toLocalDateTime();
                LocalDateTime listEndLdt = a.getEnd().toLocalDateTime();

                //Appointments on same day, check times
                if (userStartLdt.getDayOfYear() == listEndLdt.getDayOfYear()) {
                    //Starts after appointment ends
                    if ((userStartLdt.getHour() == listEndLdt.getHour() && userStartLdt.getMinute() >= listEndLdt.getMinute())
                            || (userStartLdt.getHour() > listEndLdt.getHour())) {
                        //Valid for single appointment comparison, continue checking rest
                    }
                    //Otherwise, ends before appointment starts
                    else if ((userEndLdt.getHour() == listStartLdt.getHour() && userEndLdt.getMinute() <= listStartLdt.getMinute())
                            || (userEndLdt.getHour() < listStartLdt.getHour())) {
                        //Valid for single appointment comparison, continue checking rest
                    } else {
                        //Invalid for an appointment, cannot book for this time
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("ERROR");
                        alert.setHeaderText("Invalid date and time");
                        alert.setContentText("An appointment is already booked for this date and time");
                        alert.showAndWait();
                        return true;
                    }
                }
                //Appointments on different days, no need to check times
                else {

                }
            }
            //Cannot compare appointment to itself, do nothing
            else {

            }
        }
        return false;
    }

    /**
     * Method which validates customerId
     * @return true if valid
     */
    public boolean checkCustomerId() {
        if (appointmentCustomerIdComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }

    /**
     * Method which validates userId
     * @return true if valid
     */
    public boolean checkUserId() {
        if (appointmentUserIdComboBox.getSelectionModel().getSelectedItem() == null) {
            return false;
        }
        return true;
    }
}
