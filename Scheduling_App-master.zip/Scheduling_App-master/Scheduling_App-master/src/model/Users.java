package model;

/**
 * <p>Users is a model class for the Users stored in MySQL DB.</p>
 * <p>Used to help when querying DB.</p>
 *
 * @author Jacob Douma
 */
public class Users {

    /**The ID of the given user stored in DB*/
    private int userId;

    /**The username of the given user stored in DB*/
    private String username;

    /**The password of the given user stored in DB*/
    private String password;


    /**
     * The constructor to create a new user
     * @param userId
     * @param username
     * @param password
     */
    public Users(int userId, String username, String password) {
        this.userId = userId;
        this.username = username;
        this.password = password;
    }

    /**
     * Method which sets userId
     * @param userId
     */
    public void setUserId(int userId) { this.userId = userId; }

    /**
     * Method which gets the userId
     * @return userId
     */
    public int getUserId() { return userId; }

    /**
     * Method which sets the username
     * @param username
     */
    public void setUsername(String username) { this.username = username; }

    /**
     * Method which gets the username
     * @return username
     */
    public String getUsername() { return username; }

    /**
     * Method which sets the password
     * @param password
     */
    public void setPassword(String password) { this.password = password; }

    /**
     * Method which gets the password
     * @return password
     */
    public String getPassword() { return password; }
}
