package model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.*;

/**
 * <p>Appointments is a model class for the Appointments stored in MySQL DB.</p>
 * <p>Used to help store list of appointments and populate appointments records table.</p>
 * <p>Implements Serializable for storing record of deleted appointments in DeletedAppointmentsSerialized.txt.</p>
 *
 * @author Jacob Douma
 */
public class Appointments implements Serializable {

    /**Used for consistency with serialization*/
    private static final long serialVersionUID = 6529685098267757690L;

    /**The ID of the given appointment in DB*/
    private int appointmentId;

    /**The title of the given appointment in DB*/
    private String title;

    /**The description of the given appointment in DB*/
    private String description;

    /**The location of the given appointment in DB*/
    private String location;

    /**The contact of the given appointment in DB*/
    private String contact;

    /**The type of the given appointment in DB*/
    private String type;

    /**The start of the given appointment in DB*/
    private Timestamp start;

    /**The end of the given appointment in DB*/
    private Timestamp end;

    /**The Timestamp of when the appointment was deleted*/
    private Timestamp deletedTimestamp;

    /**The customerId of the given appointment in DB*/
    private int customerId;

    /**The userId of the given appointment in DB*/
    private int userId;

    /**The contactId of the given appointment in DB*/
    private int contactId;


    /**
     * The constructor to make a new appointment
     * @param appointmentId
     * @param title
     * @param description
     * @param location
     * @param type
     * @param start
     * @param end
     * @param customerId
     * @param userId
     * @param contactId
     */
    public Appointments(int appointmentId, String title, String description, String location, String type, Timestamp start, Timestamp end, int customerId, int userId, int contactId) {
        this.appointmentId = appointmentId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.customerId = customerId;
        this.userId = userId;
        this.contactId = contactId;
    }

    /**
     * Used to verify proper appointment records
     * @return string value of appointment
     */
    public String toString() {
        String s = "";
        s = s.concat("ID: " + appointmentId + "\n");
        s = s.concat("TITLE: " + title + "\n");
        s = s.concat("DESCRIPTION: " + description + "\n");
        s = s.concat("LOCATION: " + location + "\n");
        s = s.concat("CONTACT: " + contact + "\n");
        s = s.concat("TYPE: " + type + "\n");
        s = s.concat("START: " + getStartLocal() + "\n");
        s = s.concat("END: " + getEndLocal() + "\n");
        s = s.concat("CUSTOMER_ID: " + customerId + "\n");
        s = s.concat("USER_ID: " + userId + "\n");
        s = s.concat("CONTACT_ID: " + contactId + "\n");

        return s;
    }

    /**
     * Method which sets the appointmentId of the given appointment
     * @param appointmentId
     */
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    /**
     * Method which gets the appointmentId of the given appointment
     * @return appointmentId
     */
    public int getAppointmentId() { return appointmentId; }

    /**
     * Method which sets the title of the given appointment
     * @param title
     */
    public void setTitle(String title) { this.title = title; }

    /**
     * Method which gets the title of the given appointment
     * @return title
     */
    public String getTitle() { return title; }

    /**
     * Method which sets the description of the given appointment
     * @param description
     */
    public void setDescription(String description) { this.description = description; }

    /**
     * Method which gets the description of the given appointment
     * @return description
     */
    public String getDescription() { return description; }

    /**
     * Method which sets the location of the given appointment
     * @param location
     */
    public void setLocation(String location) { this.location = location; }

    /**
     * Method which gets the location of the given appointment
     * @return location
     */
    public String getLocation() { return location; }

    /**
     * Method which sets the contact of the given appointment
     * @param contact
     */
    public void setContact(String contact) { this.contact = contact; }

    /**
     * Method which gets the contact of the given appointment
     * @return contact
     */
    public String getContact() { return contact; }

    /**
     * Method which sets the type of the given appointment
     * @param type
     */
    public void setType(String type) { this.type = type; }

    /**
     * Method which gets the type of the given appointment
     * @return type
     */
    public String getType() { return type; }

    /**
     * Method which sets the start of the given appointment
     * @param start
     */
    public void setStart(Timestamp start) { this.start = start; }

    /**
     * Method which gets the start (in UTC) of the given appointment
     * @return start
     */
    public Timestamp getStart() { return start; }

    /**
     * Method which gets the start (in local time) of the given appointment
     * @return start
     */
    public Timestamp getStartLocal() {
        Instant utcInstant = start.toInstant();
        ZonedDateTime startDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.systemDefault());
        Timestamp localTimestamp = Timestamp.from(startDateTimeZoned.toInstant());

        return localTimestamp;
    }

    /**
     * Method which sets the end of the given appointment
     * @param end
     */
    public void setEnd(Timestamp end) { this.end = end; }

    /**
     * Method which gets the end (in UTC) of the given appointment
     * @return end
     */
    public Timestamp getEnd() { return end; }

    /**
     * Method which gets the end (in local time) of the given appointment
     * @return end
     */
    public Timestamp getEndLocal() {
        Instant utcInstant = end.toInstant();
        ZonedDateTime startDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.systemDefault());
        Timestamp localTimestamp = Timestamp.from(startDateTimeZoned.toInstant());

        return localTimestamp;
    }

    /**
     * Method which sets the timestamp of the appointment deletion
     * @param deletedTimestamp
     */
    public void setDeletedTimestamp(Timestamp deletedTimestamp) { this.deletedTimestamp = deletedTimestamp; }

    /**
     * Method which gets the timestamp (in UTC) of the appointment deletion
     * @return deletedTimestamp
     */
    public Timestamp getDeletedTimestamp() { return deletedTimestamp; }

    /**
     * Method which gets the timestamp (in local time) of the appointment deletion
     * @return deletedTimestamp
     */
    public Timestamp getDeletedTimestampLocal() {
        Instant utcInstant = deletedTimestamp.toInstant();
        ZonedDateTime deletedZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.systemDefault());
        Timestamp localTimestamp = Timestamp.from(deletedZoned.toInstant());

        return localTimestamp;
    }

    /**
     * Method which sets the customerId of the given appointment
     * @param customerId
     */
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    /**
     * Method which gets the customerId of the given appointment
     * @return customerId
     */
    public int getCustomerId() { return customerId; }

    /**
     * Method which sets the userId of the given appointment
     * @param userId
     */
    public void setUserId(int userId) { this.userId = userId; }

    /**
     * Method which gets the userId of the given appointment
     * @return userId
     */
    public int getUserId() { return userId; }

    /**
     * Method which sets the contactId of the given appointment
     * @param contactId
     */
    public void setContactId(int contactId) { this.contactId = contactId; }

    /**
     * Method which gets the contactId of the given appointment
     * @return contactId
     */
    public int getContactId() { return contactId; }
}
