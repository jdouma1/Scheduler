package model;

/**
 * <p>Contacts is a model class for the contacts stored in MySQL DB.</p>
 * <p>Used to help when querying DB.</p>
 *
 * @author Jacob Douma
 */
public class Contacts {

    /**The ID of the given contact in DB*/
    private int contactId;

    /**The name of the given contact in DB*/
    private String contactName;

    /**The email of the given contact in DB*/
    private String email;


    /**
     * The constructor to create a new contact
     * @param contactId
     * @param contactName
     * @param email
     */
    public Contacts(int contactId, String contactName, String email) {
        this.contactId = contactId;
        this.contactName = contactName;
        this.email = email;
    }

    /**
     * Method which sets contactId
     * @param contactId
     */
    public void setContactId(int contactId) { this.contactId = contactId; }

    /**
     * Method which gets contactId
     * @return contactId
     */
    public int getContactId() { return contactId; }

    /**
     * Method which sets contactName
     * @param contactName
     */
    public void setContactName(String contactName) { this.contactName = contactName; }

    /**
     * Method which gets contactName
     * @return contactName
     */
    public String getContactName() { return contactName; }

    /**
     * Method which sets email
     * @param email
     */
    public void setEmail(String email) { this.email = email; }

    /**
     * Method which gets email
     * @return email
     */
    public String getEmail() { return this.email; }
}
