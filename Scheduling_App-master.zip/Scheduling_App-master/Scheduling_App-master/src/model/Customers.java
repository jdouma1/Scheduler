package model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * <p>Customers is a model class for the Customers stored in MySQL DB.</p>
 * <p>Used to help store list of customers and populate customer records table.</p>
 * <p>Implements Serializable for storing record of deleted customers in DeletedCustomersSerialized.txt.</p>
 *
 * @author Jacob Douma
 */
public class Customers implements Serializable {

    /**Used for consistency with serialization*/
    private static final long serialVersionUID = 6529685098267757690L;

    /**The ID of the given customer in DB*/
    private int id;

    /**The name of the given customer in DB*/
    private String name;

    /**The address of the given customer in DB*/
    private String address;

    /**The postalCode of the given customer in DB*/
    private String postalCode;

    /**The phone of the given customer in DB*/
    private String phone;

    /**The divisionId of the given customer in DB*/
    private int divisionId;

    /**The Timestamp of when the customer was deleted*/
    private Timestamp deletedTimestamp;


    /**The default constructor for making a new customer*/
    public Customers() {}

    /**
     * The constructor to create a new customer
     * @param id
     * @param name
     * @param address
     * @param postalCode
     * @param phone
     * @param divisionId
     */
    public Customers(int id, String name, String address, String postalCode, String phone, int divisionId) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.divisionId = divisionId;
    }

    /**
     * Used to verify proper customer records
     * @return string value of customer
     */
    public String toString() {
        String s = "";
        s = s.concat("ID: " + id + "\n");
        s = s.concat("NAME: " + name + "\n");
        s = s.concat("ADDRESS: " + address + "\n");
        s = s.concat("POSTAL CODE: " + postalCode + "\n");
        s = s.concat("PHONE: " + phone + "\n");
        s = s.concat("DIV ID: " + divisionId + "\n");

        return s;
    }

    /**
     * Method which sets the id of the given customer
     * @param id
     */
    public void setId(int id) { this.id = id; }

    /**
     * Method which gets the id of the given customer
     * @return id
     */
    public int getId() { return id; }

    /**
     * Method which sets the name of the given customer
     * @param name
     */
    public void setName(String name) { this.name = name; }

    /**
     * Method which gets the name of the given customer
     * @return name
     */
    public String getName() { return name; }

    /**
     * Method which sets the address of the given customer
     * @param address
     */
    public void setAddress(String address) { this.address = address; }

    /**
     * Method which gets the address of the given customer
     * @return address
     */
    public String getAddress() { return address; }

    /**
     * Method which sets the postalCode of the given customer
     * @param postalCode
     */
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    /**
     * Method which gets the postalCode of the given customer
     * @return postalCode
     */
    public String getPostalCode() { return postalCode; }

    /**
     * Method which sets the phone of the given customer
     * @param phone
     */
    public void setPhone(String phone) { this.phone = phone; }

    /**
     * Method which gets the phone of the given customer
     * @return phone
     */
    public String getPhone() { return phone; }

    /**
     * Method which sets the divisionId of the given customer
     * @param divisionId
     */
    public void setDivisionId(int divisionId) { this.divisionId = divisionId; }

    /**
     * Method which gets the divisionId of the given customer
     * @return divisionId
     */
    public int getDivisionId() { return divisionId; }

    /**
     * Method which sets the timestamp of the customer deletion
     * @param deletedTimestamp
     */
    public void setDeletedTimestamp(Timestamp deletedTimestamp) { this.deletedTimestamp = deletedTimestamp; }

    /**
     * Method which gets the timestamp (in UTC) of the customer deletion
     * @return timestamp in UTC
     */
    public Timestamp getDeletedTimestamp() { return deletedTimestamp; }

    /**
     * Method which gets the timestamp (in local time) of the customer deletion
     * @return timestamp in local time
     */
    public Timestamp getDeletedTimestampLocal() {
        Instant utcInstant = deletedTimestamp.toInstant();
        ZonedDateTime deletedZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.systemDefault());
        Timestamp localTimestamp = Timestamp.from(deletedZoned.toInstant());

        return localTimestamp;
    }
}
