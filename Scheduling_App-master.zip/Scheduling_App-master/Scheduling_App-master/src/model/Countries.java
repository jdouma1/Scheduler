package model;

/**
 * <p>Countries is a model class for the Countries stored in MySQL DB.</p>
 * <p>Used to help when querying DB.</p>
 *
 * @author Jacob Douma
 */
public class Countries {

    /**The ID of the given country in DB*/
    private int countryId;

    /**The name of the given country in DB*/
    private String country;


    /**
     * The constructor to create a new country
     * @param countryId
     * @param country
     */
    public Countries(int countryId, String country) {
        this.countryId = countryId;
        this.country = country;
    }

    /**
     * Method which sets countryId
     * @param countryId
     */
    public void setCountryId(int countryId) { this.countryId = countryId; }

    /**
     * Method which gets countryId
     * @return countryId
     */
    public int getCountryId() { return countryId; }

    /**
     * Method which sets country name
     * @param country name
     */
    public void setCountry(String country) { this.country = country; }

    /**
     * Method which gets country name
     * @return country name
     */
    public String getCountry() { return country; }
}
