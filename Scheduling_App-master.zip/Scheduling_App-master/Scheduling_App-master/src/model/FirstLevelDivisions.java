package model;

/**
 * <p>FirstLevelDivisions is a model class for the FirstLevelDivisions stored in MySQL DB.</p>
 * <p>Used to help when querying DB.</p>
 *
 * @author Jacob Douma
 */
public class FirstLevelDivisions {

    /**The ID of the given first level division in DB*/
    private int divisionId;

    /**The name of the given first level division in DB*/
    private String division;

    /**The country ID of the given first level division's corresponding country in DB*/
    private int countryId;


    /**
     * The constructor to create a new first level division
     * @param divisionId
     * @param division
     * @param countryId
     */
    public FirstLevelDivisions(int divisionId, String division, int countryId) {
        this.divisionId = divisionId;
        this.division = division;
        this.countryId = countryId;
    }

    /**
     * Method which sets divisionID
     * @param divisionId
     */
    public void setDivisionId(int divisionId) { this.divisionId = divisionId; }

    /**
     * Method which gets divisionId
     * @return divisionId
     */
    public int getDivisionId() { return divisionId; }

    /**
     * Method which sets division
     * @param division
     */
    public void setDivision(String division) { this.division = division; }

    /**
     *Method which gets division
     * @return division
     */
    public String getDivision() { return division; }

    /**
     * Method which sets countryId
     * @param countryId
     */
    public void setCountryId(int countryId) { this.countryId = countryId; }

    /**
     * Method which gets countryId
     * @return countryId
     */
    public int getCountryId() { return countryId; }
}
