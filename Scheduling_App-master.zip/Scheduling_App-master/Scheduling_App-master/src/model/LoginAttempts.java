package model;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * <p>LoginAttempts is a model class for the login attempts stored in login_activity.txt in project folder.</p>
 * <p>Used to track login attempts.</p>
 *
 * @author Jacob Douma
 */
public class LoginAttempts {

    /**The username used in the login attempt*/
    private String username;

    /**The Timestamp of the login attempt*/
    private Timestamp timestamp;

    /**Identifies whether the login attempt was successful*/
    private boolean successful;


    /**
     * The constructor to create a new login attempt
     * @param username
     * @param timestamp
     * @param successful
     */
    public LoginAttempts(String username, Timestamp timestamp, boolean successful) {
        this.username = username;
        this.timestamp = timestamp;
        this.successful = successful;
    }

    /**
     * Used to append login attempt to login_activity.txt in project folder
     * @return string value of login attempt
     */
    public String toString() {
        String s = "";
        s = s.concat("USERNAME: " + username + "\n");
        s = s.concat("TIMESTAMP: " + timestamp + "\n");
        s = s.concat("SUCCESSFUL: " + successful + "\n\n");

        return s;
    }

    /**
     * Method which sets the username used in the login attempt
     * @param username
     */
    public void setUsername(String username) { this.username = username; }

    /**
     * Method which gets the username used in the login attempt
     * @return username
     */
    public String getUsername() { return username; }

    /**
     * Method which sets the timestamp of the login attempt
     * @param timestamp
     */
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }

    /**
     * Method which gets the timestamp (in UTC) of the login attempt
     * @return timestamp in UTC
     */
    public Timestamp getTimestamp() { return timestamp; }

    /**
     * Method which gets the timestamp (in local time) of the login attempt
     * @return timestamp in local time
     */
    public Timestamp getTimestampLocal() {
        Instant utcInstant = timestamp.toInstant();
        ZonedDateTime startDateTimeZoned = ZonedDateTime.ofInstant(utcInstant, ZoneId.systemDefault());
        Timestamp localTimestamp = Timestamp.from(startDateTimeZoned.toInstant());

        return localTimestamp;
    }

    /**
     * Method which sets whether the login attempt was successful
     * @param successful
     */
    public void setSuccessful(boolean successful) { this.successful = successful; }

    /**
     * Method which gets whether the login attempt was successful
     * @return successful
     */
    public boolean getSuccessful() { return successful; }
}
