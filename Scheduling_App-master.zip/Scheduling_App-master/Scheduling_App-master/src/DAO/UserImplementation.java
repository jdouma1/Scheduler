package DAO;

import model.Users;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * </p>UserImplementation is a DAO class for querying MySQL DB for a given user.</p>
 * </p>Used to help validate or invalidate users.</p>
 *
 * @author Jacob Douma
 */
public class UserImplementation {

    /**
     * Method which queries MySQL DB for user with matching username
     * @param username
     * @return the found user, otherwise null
     * @throws SQLException
     */
    public static Users getUser(String username) throws SQLException {
        Users user;

        String sqlStmnt = "SELECT * FROM users WHERE User_Name = '" + username + "'";
        Query.makeQuery(sqlStmnt);
        ResultSet queryResult = Query.getResult();

        while(queryResult.next()) {
            int userId = queryResult.getInt("User_ID");
            String userName = queryResult.getString("User_Name");
            String password = queryResult.getString("Password");

            user = new Users(userId, userName, password);
            return user;
        }
        return null;
    }
}
