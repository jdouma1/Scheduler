package DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointments;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;


/**
 * <p>AppointmentsImplementation is a DAO class for querying MySQL DB for a given appointment.</p>
 * <p>Used to help customers add, update, delete, and search appointments in DB.</p>
 *
 * @author Jacob Douma
 */
public class AppointmentsImplementation {

    /**List of all appointments in DB*/
    private static ObservableList<Appointments> allAppointments = FXCollections.observableArrayList();

    /**List of all deleted appointments from DB*/
    private static ObservableList<Appointments> deletedAppointments = FXCollections.observableArrayList();

    /**HashMap created for filtering total appointment records by Type*/
    private static HashMap<String, Integer> appointmentsByType = new HashMap();

    /**HashMap created for filtering total appointment records by Month*/
    private static HashMap<String, Integer> appointmentsByMonth = new HashMap();

    /**Index to track which ID to give to next added appointment*/
    private static int nextId = 0;

    /**Tracks if allAppointments has yet been initialized to appointments held in DB*/
    private static boolean initialized = false;


    /**
     * Method which initializes allAppointments to appointments in DB
     */
    public static void initialize() {
        if (!initialized) {
            initialized = true;
            String query = "SELECT * FROM appointments ORDER BY Appointment_ID";
            Query.makeQuery(query);
            ResultSet result = Query.getResult();

            try {
                while (result.next()) {
                    int appointmentId = result.getInt("Appointment_ID");
                    nextId = appointmentId;
                    String title = result.getString("Title");
                    String description = result.getString("Description");
                    String location = result.getString("Location");
                    String type = result.getString("Type");
                    Timestamp start = Timestamp.valueOf(result.getString("Start"));
                    Timestamp end = Timestamp.valueOf(result.getString("End"));
                    int customerId = result.getInt("Customer_ID");
                    int userId = result.getInt("User_ID");
                    int contactId = result.getInt("Contact_ID");

                    Query.makeQuery("SELECT Contact_Name FROM contacts WHERE Contact_ID = '" + contactId + "'");
                    ResultSet r = Query.getResult();
                    r.next();

                    Appointments a = new Appointments(appointmentId, title, description, location, type, start, end, customerId, userId, contactId);
                    a.setContact(r.getString("Contact_Name"));
                    allAppointments.add(a);
                    addAppointmentType(type);
                    addAppointmentMonth(start.toLocalDateTime().getMonth().toString());
                }
            } catch (Exception e) {

            }
        }
    }

    /**
     * Method which adds an appointment type to appointmentsByType and increments if repeated
     * @param type
     */
    public static void addAppointmentType(String type) {
        if (appointmentsByType.get(type) == null) {
            appointmentsByType.put(type, 1);
        }
        else {
            int count = appointmentsByType.get(type) + 1;
            appointmentsByType.replace(type, count);
        }
    }

    /**
     * Method which gets appointmentsByType
     * @return appointmentsByType
     */
    public static HashMap<String, Integer> getAppointmentsByType() {
        return appointmentsByType;
    }

    /**
     * Method which adds an appointment month to addAppointmentMonth and increments if repeated
     * @param month
     */
    public static void addAppointmentMonth(String month) {
        if (appointmentsByMonth.get(month) == null) {
            appointmentsByMonth.put(month, 1);
        }
        else {
            int count = appointmentsByMonth.get(month) + 1;
            appointmentsByMonth.replace(month, count);
        }
    }

    /**
     * Method which gets appointmentsByMonth
     * @return appointmentsByMonth
     */
    public static HashMap<String, Integer> getAppointmentsByMonth() {
        return appointmentsByMonth;
    }

    /**
     * Method which adds a given appointment to allAppointments and inserts into DB
     * @param a
     * @throws SQLException
     */
    public static void add(Appointments a) throws SQLException {
        if (!allAppointments.contains(a)) {
            allAppointments.add(a);
            addAppointmentType(a.getType());
            addAppointmentMonth(a.getStartLocal().toLocalDateTime().getMonth().toString());

            String sql = "INSERT INTO appointments (Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setString(1, String.valueOf(a.getAppointmentId()));
            ps.setString(2, a.getTitle());
            ps.setString(3, a.getDescription());
            ps.setString(4, a.getLocation());
            ps.setString(5, a.getType());
            ps.setString(6, a.getStart().toString());
            ps.setString(7, a.getEnd().toString());
            ps.setString(8, String.valueOf(a.getCustomerId()));
            ps.setString(9, String.valueOf(a.getUserId()));
            ps.setString(10, String.valueOf(a.getContactId()));
            int rowsAffected = ps.executeUpdate();
        }
    }

    /**
     * Method which updates appointment data in local copy and in DB to appointment supplied
     * @param id
     * @param a
     */
    public static void update(int id, Appointments a) {
        for (int i = 0; i < allAppointments.size(); ++i) {
            if (allAppointments.get(i).getAppointmentId() == id) {
                allAppointments.set(i, a);
                String sql = "UPDATE appointments SET Title = '" + a.getTitle() + "', Description = '" + a.getDescription() + "', Location = '" + a.getLocation() + "', Type = '" + a.getType() + "', Start = '" + a.getStart().toString() + "', End = '" + a.getEnd().toString() + "', Customer_ID = '" + a.getCustomerId() + "', User_ID = '" + a.getUserId() + "', Contact_ID = '" + a.getContactId() + "' WHERE Appointment_ID = '" + a.getAppointmentId() + "'";
                Query.makeQuery(sql);
                return;
            }
        }
    }

    /**
     * Method which deletes given appointment from allAppointments and DB
     * @param a
     */
    public static void delete(Appointments a) {
        Instant deletedTimeLocalInstant = Instant.now();
        ZonedDateTime utcDeletedTime = ZonedDateTime.ofInstant(deletedTimeLocalInstant, ZoneId.of("UTC"));
        Timestamp utcInstant = Timestamp.from(utcDeletedTime.toInstant());

        a.setDeletedTimestamp(utcInstant);
        deletedAppointments.add(a);
        allAppointments.remove(a);

        String sql = "DELETE FROM appointments WHERE Appointment_ID = '" + a.getAppointmentId() + "'";
        Query.makeQuery(sql);
    }

    /**
     * Method which searches and gets appointment by appointmentId
     * @param id
     * @return found appointment, otherwise null
     */
    public static Appointments getAppointment(int id) {
        for (int i = 0; i < allAppointments.size(); ++i) {
            if (allAppointments.get(i).getAppointmentId() == id) {
                return allAppointments.get(i);
            }
        }
        return null;
    }

    /**
     * Method which gets allAppointments
     * @return allAppointments
     */
    public static ObservableList<Appointments> getAllAppointments() { return allAppointments; }

    /**
     * Method which increments then returns nextId
     * @return nextId
     */
    public static int getNextId() { return ++nextId; }

    /**
     * Method which sets all deletedAppointments to list provided
     * @param deleted
     */
    public static void setAllDeletedAppointments(ObservableList<Appointments> deleted) { deletedAppointments = deleted; }

    /**
     * Method which gets all deletedAppointments
     * @return deletedAppointments
     */
    public static ObservableList<Appointments> getAllDeletedAppointments() { return deletedAppointments; }
}
