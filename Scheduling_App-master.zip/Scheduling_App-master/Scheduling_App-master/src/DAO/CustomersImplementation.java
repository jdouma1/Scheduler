package DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;


/**
 * <p>CustomersImplementation is a DAO class for querying MySQL DB for a given customer.</p>
 * <p>Used to help customers add, update, delete, and search customers in DB.</p>
 *
 * @author Jacob Douma
 */
public class CustomersImplementation {

    /**List of all customers in DB*/
    private static ObservableList<Customers> allCustomers = FXCollections.observableArrayList();

    /**List of all deleted customers from DB*/
    private static ObservableList<Customers> deletedCustomers = FXCollections.observableArrayList();

    /**Index to track which ID to give to next added customer*/
    private static int nextId = 0;

    /**Tracks if allCustomers has yet been initialized to customers held in DB*/
    private static boolean initialized = false;


    /**
     * Method which initializes allCustomers to customers in DB
     */
    public static void initialize() {
        if (!initialized) {
            initialized = true;
            String query = "SELECT * FROM customers ORDER BY Customer_ID";
            Query.makeQuery(query);
            ResultSet result = Query.getResult();

            try {
                while (result.next()) {
                    int id = result.getInt("Customer_ID");
                    nextId = id;
                    String name = result.getString("Customer_Name");
                    String address = result.getString("Address");
                    String postalCode = result.getString("Postal_Code");
                    String phone = result.getString("Phone");
                    int divisionId = result.getInt("Division_ID");

                    Customers c = new Customers(id, name, address, postalCode, phone, divisionId);
                    allCustomers.add(c);
                }
            } catch (Exception e) {

            }
        }
    }

    /**
     * Method which adds a given customer to allCustomers and inserts into DB
     * @param c
     * @throws SQLException
     */
    public static void add(Customers c) throws SQLException {
        if (!allCustomers.contains(c)) {
            allCustomers.add(c);

            String sql = "INSERT INTO customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
            ps.setString(1, String.valueOf(c.getId()));
            ps.setString(2, c.getName());
            ps.setString(3, c.getAddress());
            ps.setString(4, c.getPostalCode());
            ps.setString(5, c.getPhone());
            ps.setString(6, String.valueOf(c.getDivisionId()));
            int rowsAffected = ps.executeUpdate();
        }
    }

    /**
     * Method which updates customer data in local copy and in DB to customer supplied
     * @param id
     * @param c
     */
    public static void update(int id, Customers c) {
        for (int i = 0; i < allCustomers.size(); ++i) {
            if (allCustomers.get(i).getId() == id) {
                allCustomers.set(i, c);
                String sql = "UPDATE customers SET Customer_Name = '" + c.getName() + "', Address = '" + c.getAddress() + "', Postal_Code = '" + c.getPostalCode() + "', Phone = '" + c.getPhone() + "', Division_ID = '" + c.getDivisionId() + "' WHERE Customer_ID = '" + c.getId() + "'";
                Query.makeQuery(sql);
                return;
            }
        }
    }

    /**
     * Method which deletes given customer from allCustomers and DB
     * @param c
     */
    public static void delete(Customers c) {
        Instant deletedTimeLocalInstant = Instant.now();
        ZonedDateTime utcDeletedTime = ZonedDateTime.ofInstant(deletedTimeLocalInstant, ZoneId.of("UTC"));
        Timestamp utcInstant = Timestamp.from(utcDeletedTime.toInstant());

        c.setDeletedTimestamp(utcInstant);
        deletedCustomers.add(c);
        allCustomers.remove(c);

        String sql = "DELETE FROM customers WHERE Customer_ID = '" + c.getId() + "'";
        Query.makeQuery(sql);
    }

    /**
     * Method which searches and gets customer by ID
     * @param id
     * @return found customer, otherwise null
     */
    public static Customers getCustomer(int id) {
        for (int i = 0; i < allCustomers.size(); ++i) {
            if (allCustomers.get(i).getId() == id) {
                return allCustomers.get(i);
            }
        }
        return null;
    }

    /**
     * Method which gets allCustomers
     * @return allCustomers
     */
    public static ObservableList<Customers> getAllCustomers() { return allCustomers; }

    /**
     * Method which increments then returns nextId
     * @return nextId
     */
    public static int getNextId() { return ++nextId; }

    /**
     * Method which sets all deletedCustomers to list provided
     * @param deleted
     */
    public static void setAllDeletedCustomers(ObservableList<Customers> deleted) {deletedCustomers = deleted;}

    /**
     * Method which gets all deletedCustomers
     * @return deletedCustomers
     */
    public static ObservableList<Customers> getAllDeletedCustomers() { return deletedCustomers; }
}
