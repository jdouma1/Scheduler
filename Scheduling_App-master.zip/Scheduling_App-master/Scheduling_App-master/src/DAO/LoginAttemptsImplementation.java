package DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.LoginAttempts;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;


/**
 * <p>LoginAttemptsImplementation is a DAO class for tracking login attempts.</p>
 * <p>Used to help store and append login attempts to login_activity.txt.</p>
 *
 * @author Jacob Douma
 */
public class LoginAttemptsImplementation {

    /**A list of all login attempts in this session to be appended*/
    private static ObservableList<LoginAttempts> allLoginAttempts = FXCollections.observableArrayList();


    /**
     * Method which adds a new login attempt to allLoginAttempts
     * @param attempt
     */
    public static void addLoginAttempt(LoginAttempts attempt) {
        allLoginAttempts.add(attempt);
    }

    /**
     * A method which sets allLoginAttempts to list provided
     * @param attempts
     */
    public static void setAllLoginAttempts(ObservableList<LoginAttempts> attempts) { allLoginAttempts = attempts; }

    /**
     * A method which gets allLoginAttempts
     * @return allLoginAttempts
     */
    public static ObservableList<LoginAttempts> getAllLoginAttempts() { return allLoginAttempts; }

    /**
     * <p>A method which appends allLoginAttempts from session to login_activity.txt</p>
     * <p>Used lambda to easily append each login attempt to login_activity.txt</p>
     */
    public static void appendLoginAttempts() {
        ObservableList<LoginAttempts> allLoginAttempts = LoginAttemptsImplementation.getAllLoginAttempts();
        String loginFilename = "Scheduling_App-master/src/Utilities/login_activity.txt";

        try {
            //USED LAMBDA
            allLoginAttempts.forEach(a -> {
                try {
                    Files.write(Paths.get(loginFilename), a.toString().getBytes(), StandardOpenOption.APPEND);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            System.out.println("Login attempts have been appended");
        }

        catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
