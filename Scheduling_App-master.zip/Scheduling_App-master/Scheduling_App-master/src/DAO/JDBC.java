package DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


/**
 * JDBC is a DAO class for establishing a connecting to MySQL DB and making prepared statements
 *
 * @author Software II Course Instructors
 */
public class JDBC {
 private static final String protocol = "jdbc";
     private static final String vendor = ":mysql:";
         private static final String location = "//localhost:3306/";
             private static final String databaseName = "client_schedule";
                /**URL used to establish DB connection*/
                private static final String jdbcUrl = protocol + vendor + location + databaseName + "?connectionTimeZone = SERVER"; // LOCAL
        private static final String driver = "com.mysql.cj.jdbc.Driver"; // Driver reference
        /**userName used to establish DB connection*/
        private static final String userName = "sqlUser"; // Username
        /**password used to establish DB connection*/
        private static String password = "Passw0rd!"; // Password
        /**The connection made to the DB*/
        private static Connection connection = null;  // Connection Interface
        /**The prepared statement created from SQL command*/
        private static PreparedStatement preparedStatement;

    /**
     * Method which makes a connection to DB
     */
    public static void makeConnection() {

          try {
              Class.forName(driver); // Locate Driver
              //password = Details.getPassword(); // Assign password
              connection = DriverManager.getConnection(jdbcUrl, userName, password); // reference Connection object
              System.out.println("Connection successful!");
          }
                  catch(ClassNotFoundException e) {
                      System.out.println("Error:" + e.getMessage());
                  }
                  catch(SQLException e) {
                      System.out.println("Error:" + e.getMessage());
                  }
          }

    /**
     * Method which gets the connection made to DB
     * @return connection
     */
    public static Connection getConnection() {
                return connection;
            }

    /**
     * Method which closes the connection made to DB
     */
    public static void closeConnection() {
                 try {
                     connection.close();
                     System.out.println("Connection closed!");
                 } catch (SQLException e) {
                     System.out.println(e.getMessage());
                 }
             }

    /**
     * Method which makes the prepared statement to DB through connection
     * @param sqlStatement
     * @param conn
     * @throws SQLException
     */
    public static void makePreparedStatement(String sqlStatement, Connection conn) throws SQLException {
           if (conn != null)
               preparedStatement = conn.prepareStatement(sqlStatement);
           else
               System.out.println("Prepared Statement Creation Failed!");
       }

    /**
     * Method which gets the prepared statement made to DB through connection
     * @return preparedStatement
     * @throws SQLException
     */
    public static PreparedStatement getPreparedStatement() throws SQLException {
           if (preparedStatement != null)
               return preparedStatement;
           else System.out.println("Null reference to Prepared Statement");
           return null;
       }



}