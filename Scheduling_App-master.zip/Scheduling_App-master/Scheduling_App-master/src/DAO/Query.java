package DAO;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 * <p>Query is a DAO class for making queries and fetching their results for MySQL DB.</p>
 * <p>Used to help CRUD operations with DB.</p>
 *
 * @author Jacob Douma
 */
public class Query {

    /**The given query to the DB*/
    private static String query;

    /**The given statement made from the query*/
    private static Statement stmnt;

    /**The result retrieved from the query*/
    private static ResultSet result;


    /**
     * Method which performs a CRUD query to the DB
     * @param query
     */
    public static void makeQuery(String query) {
        query = query;

        try {
            JDBC.makePreparedStatement(query, JDBC.getConnection());
            stmnt = JDBC.getPreparedStatement();

            if (query.toLowerCase().startsWith("select")) {
                result = stmnt.executeQuery(query);
            }
            else if (query.toLowerCase().startsWith("insert") || query.toLowerCase().startsWith("update") || query.toLowerCase().startsWith("delete")) {
                stmnt.executeUpdate(query);
            }
        }
        catch(Exception e) {
            System.out.println("ERROR" + e.getMessage());
        }
    }

    /**
     * Method which retrieves the result from the query to the DB
     * @return result
     */
    public static ResultSet getResult() { return result; }
}
